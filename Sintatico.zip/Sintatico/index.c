#include "syntatic.tab.h"
#include "structure.h"
#include <stdio.h>


int main() {
	printf("OI");
}
