int func (int a, float asd, int vc) {
	int x;
	for ( x = 3; i > 3 ; i = i + 1 ) {
		int k;
		k = 9;
		if ( k ) {
			set varSet;
		}
	}

	return 1;
}

int main() {
	return 1;
}
