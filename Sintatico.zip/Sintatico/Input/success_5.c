int main(){
    if(f( (1 + 2) - b, 3 / (((3))), exists(b in add(1 in add(2 in s))))){
        write("puts");
    }
    if( (13 in b) || (is_set(b)) ){
        writeln("eita");
        x = is_set(b);
    }
}