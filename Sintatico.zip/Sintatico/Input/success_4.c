int main(){
    add( exists(a in b) in add(1 + 2 in b));
     add(1 in add(2 in add(5 in add(8 in s))));
}