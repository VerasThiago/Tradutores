int funcao() {
	set int setDeclaracaoErrada;

	return 0;
}
