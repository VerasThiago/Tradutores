int main() {
    int x;
    set s;
    for(i = 0; i < n; i = i + 1){
        if(x > 3){
            return 0;
        }
    }
}