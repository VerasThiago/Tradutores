int semParenteses {
	int x = 1 + 1 / 3;

	return 0;
}
