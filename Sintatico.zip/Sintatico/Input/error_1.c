int f() {
	List <int> lista;

	int varSemPontoVirgula

	return 0;
}
