set func1(int a){
    int b;
}

int func2(int c, set d){
    int e;
    int f;
}

int func (int a, float asd, int vc) {
	int x;
	for ( x = 3; i > 3 ; i = i + 1 ) {
		int k;
		k = 9;
		if ( k ) {
			set varSet;
		}
	}

	return 1;
}

int main() {
    int x;
    set s;
    for(i = 0; i < n; i = i + 1){
        if(x > 3){
            return 0;
        }
    }
}

int main(){
    if(f( (1 + 2) - b, 3 / (((3))), exists(b in add(1 in add(2 in s))))){
        write("puts");
    }
    if( (1) + (2) ){
        writeln("eita");
        x = is_set(b);
    }
}

int main(){
    add( exists(a in b) in add(1 + 2 in b));
     add(1 in add(2 in add(5 in add(8 in s))));
}

int main() {
	return 1;
}


set subsum(set s, int target, int cur_sum, set ans) {
    if(target == cur_sum) {
        return ans;
    }
    else {
        
    }
    // Important comment
    if(EMPTY) {
        int el;
        remove((exists (el in s)) in s);
        if(subsum(s, target, cur_sum, ans)) return ans;
        cur_sum = curr_sum + el;
        add(el in ans);
        if(subsum(s, target, cur_sum, ans)) return ans;
        add(el in s);
        remove (el in s);
        return EMPTY;
    }
}

set S;

int main(int argc) {
    write("OK");
}

set subsum(set s, int target, int cur_sum, set ans){
    int val;
    read(val);
    if (target == cur_sum){
        return ans;
    } else {
        int el;
        if (subsum(s, target, cur_sum, ans))
            return ans;
        cur_sum = curr_sum + el;
        if (subsum(s, target, cur_sum, ans)){
            return ans;
        }
        for(el = 0; el < n; el = el + 1) {
            return EMPTY;
        }
    }
}

int main(){
    int g;
    int h;
    if(i){
        int j;
    }
    if(k){
        int l;
    }
    if(m){
        int n;
    
    }
    int o;
    int p;
    int q;
    if(r){
        int s;
    }
    int qwuhdqhuwdhut;
    int u;
    int v;
}