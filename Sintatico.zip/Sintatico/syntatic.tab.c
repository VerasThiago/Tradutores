/* A Bison parser, made by GNU Bison 3.7.6.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30706

/* Bison version string.  */
#define YYBISON_VERSION "3.7.6"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 8 "syntatic.y"

    #include <stdlib.h>
    #include <stdio.h>
    #include <string.h>
    #include "stack.h"
    #include "table.h"
    #include "tree.h"

    extern int yylex();
    extern int yyparse();
    extern int yyerror(const char* message);
    extern int yylex_destroy();
    extern FILE* yyin;


#line 87 "syntatic.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "syntatic.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_3_ = 3,                         /* ','  */
  YYSYMBOL_4_ = 4,                         /* '{'  */
  YYSYMBOL_5_ = 5,                         /* '('  */
  YYSYMBOL_6_ = 6,                         /* '}'  */
  YYSYMBOL_7_ = 7,                         /* ')'  */
  YYSYMBOL_8_ = 8,                         /* ';'  */
  YYSYMBOL_9_ = 9,                         /* '='  */
  YYSYMBOL_ELEM = 10,                      /* ELEM  */
  YYSYMBOL_IF = 11,                        /* IF  */
  YYSYMBOL_ELSE = 12,                      /* ELSE  */
  YYSYMBOL_SET = 13,                       /* SET  */
  YYSYMBOL_AND_OP = 14,                    /* AND_OP  */
  YYSYMBOL_OR_OP = 15,                     /* OR_OP  */
  YYSYMBOL_FOR = 16,                       /* FOR  */
  YYSYMBOL_RETURN = 17,                    /* RETURN  */
  YYSYMBOL_WRITE = 18,                     /* WRITE  */
  YYSYMBOL_WRITELN = 19,                   /* WRITELN  */
  YYSYMBOL_READ = 20,                      /* READ  */
  YYSYMBOL_EMPTY = 21,                     /* EMPTY  */
  YYSYMBOL_FLOAT = 22,                     /* FLOAT  */
  YYSYMBOL_INT = 23,                       /* INT  */
  YYSYMBOL_ADD = 24,                       /* ADD  */
  YYSYMBOL_REMOVE = 25,                    /* REMOVE  */
  YYSYMBOL_EXISTS = 26,                    /* EXISTS  */
  YYSYMBOL_FOR_ALL = 27,                   /* FOR_ALL  */
  YYSYMBOL_IS_SET = 28,                    /* IS_SET  */
  YYSYMBOL_IN = 29,                        /* IN  */
  YYSYMBOL_INT_VALUE = 30,                 /* INT_VALUE  */
  YYSYMBOL_FLOAT_VALUE = 31,               /* FLOAT_VALUE  */
  YYSYMBOL_ID = 32,                        /* ID  */
  YYSYMBOL_STRING = 33,                    /* STRING  */
  YYSYMBOL_RELATIONAL_OP = 34,             /* RELATIONAL_OP  */
  YYSYMBOL_MULTIPLICATIVE_OP = 35,         /* MULTIPLICATIVE_OP  */
  YYSYMBOL_ADDITIVE_OP = 36,               /* ADDITIVE_OP  */
  YYSYMBOL_YYACCEPT = 37,                  /* $accept  */
  YYSYMBOL_start = 38,                     /* start  */
  YYSYMBOL_program = 39,                   /* program  */
  YYSYMBOL_function_definition = 40,       /* function_definition  */
  YYSYMBOL_function_declaration = 41,      /* function_declaration  */
  YYSYMBOL_function_body = 42,             /* function_body  */
  YYSYMBOL_parameters = 43,                /* parameters  */
  YYSYMBOL_parameters_list = 44,           /* parameters_list  */
  YYSYMBOL_parameter = 45,                 /* parameter  */
  YYSYMBOL_type_identifier = 46,           /* type_identifier  */
  YYSYMBOL_statements = 47,                /* statements  */
  YYSYMBOL_statements_braced = 48,         /* statements_braced  */
  YYSYMBOL_statement = 49,                 /* statement  */
  YYSYMBOL_set_pre_statement = 50,         /* set_pre_statement  */
  YYSYMBOL_set_statement_add_remove = 51,  /* set_statement_add_remove  */
  YYSYMBOL_set_statement_for_all = 52,     /* set_statement_for_all  */
  YYSYMBOL_set_statement_exists = 53,      /* set_statement_exists  */
  YYSYMBOL_set_boolean_expression = 54,    /* set_boolean_expression  */
  YYSYMBOL_set_assignment_expression = 55, /* set_assignment_expression  */
  YYSYMBOL_expression_statement = 56,      /* expression_statement  */
  YYSYMBOL_expression = 57,                /* expression  */
  YYSYMBOL_expression_assignment = 58,     /* expression_assignment  */
  YYSYMBOL_expression_logical = 59,        /* expression_logical  */
  YYSYMBOL_expression_relational = 60,     /* expression_relational  */
  YYSYMBOL_expression_additive = 61,       /* expression_additive  */
  YYSYMBOL_expression_multiplicative = 62, /* expression_multiplicative  */
  YYSYMBOL_expression_value = 63,          /* expression_value  */
  YYSYMBOL_is_set_statement = 64,          /* is_set_statement  */
  YYSYMBOL_is_set_expression = 65,         /* is_set_expression  */
  YYSYMBOL_for = 66,                       /* for  */
  YYSYMBOL_for_expression = 67,            /* for_expression  */
  YYSYMBOL_io_statement = 68,              /* io_statement  */
  YYSYMBOL_arguments_list = 69,            /* arguments_list  */
  YYSYMBOL_conditional = 70,               /* conditional  */
  YYSYMBOL_conditional_expression = 71,    /* conditional_expression  */
  YYSYMBOL_return = 72,                    /* return  */
  YYSYMBOL_value = 73,                     /* value  */
  YYSYMBOL_function_call_statement = 74,   /* function_call_statement  */
  YYSYMBOL_function_call = 75,             /* function_call  */
  YYSYMBOL_variables_declaration = 76,     /* variables_declaration  */
  YYSYMBOL_const = 77                      /* const  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
             && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  12
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   3548

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  37
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  41
/* YYNRULES -- Number of rules.  */
#define YYNRULES  89
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  380

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   284


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       5,     7,     2,     2,     3,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     8,
       2,     9,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     4,     2,     6,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   114,   114,   125,   130,   137,   147,   155,   162,   166,
     177,   183,   191,   200,   208,   217,   227,   235,   243,   251,
     262,   269,   275,   284,   290,   298,   304,   310,   316,   322,
     328,   334,   340,   346,   355,   361,   370,   377,   387,   397,
     406,   413,   422,   428,   437,   446,   455,   461,   471,   477,
     483,   489,   495,   504,   510,   521,   527,   538,   544,   555,
     561,   567,   574,   583,   592,   601,   611,   622,   627,   633,
     639,   645,   654,   661,   670,   677,   688,   697,   703,   711,
     717,   724,   733,   743,   751,   761,   771,   775,   782,   788
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "','", "'{'", "'('",
  "'}'", "')'", "';'", "'='", "ELEM", "IF", "ELSE", "SET", "AND_OP",
  "OR_OP", "FOR", "RETURN", "WRITE", "WRITELN", "READ", "EMPTY", "FLOAT",
  "INT", "ADD", "REMOVE", "EXISTS", "FOR_ALL", "IS_SET", "IN", "INT_VALUE",
  "FLOAT_VALUE", "ID", "STRING", "RELATIONAL_OP", "MULTIPLICATIVE_OP",
  "ADDITIVE_OP", "$accept", "start", "program", "function_definition",
  "function_declaration", "function_body", "parameters", "parameters_list",
  "parameter", "type_identifier", "statements", "statements_braced",
  "statement", "set_pre_statement", "set_statement_add_remove",
  "set_statement_for_all", "set_statement_exists",
  "set_boolean_expression", "set_assignment_expression",
  "expression_statement", "expression", "expression_assignment",
  "expression_logical", "expression_relational", "expression_additive",
  "expression_multiplicative", "expression_value", "is_set_statement",
  "is_set_expression", "for", "for_expression", "io_statement",
  "arguments_list", "conditional", "conditional_expression", "return",
  "value", "function_call_statement", "function_call",
  "variables_declaration", "const", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_int16 yytoknum[] =
{
       0,   256,   257,    44,   123,    40,   125,    41,    59,    61,
     258,   259,   260,   261,   262,   263,   264,   265,   266,   267,
     268,   269,   270,   271,   272,   273,   274,   275,   276,   277,
     278,   279,   280,   281,   282,   283,   284
};
#endif

#define YYPACT_NINF (-219)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-90)

#define yytable_value_is_error(Yyn) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     200,   820,   -18,    -6,    24,    25,    73,    75,   851,    79,
      48,   200,  -219,    85,   776,   257,   106,   134,   137,    67,
     118,   148,   381,   421,  1128,   134,   759,   123,   960,  1683,
     135,  1361,   224,   226,   622,   267,   269,   287,  3135,   294,
     323,   342,   349,   358,  3147,  3158,  1203,   300,   153,   365,
     367,  1730,  1767,   302,  1800,  3170,   345,  1833,    39,    47,
     576,   498,  1153,  3181,  3193,  1866,   854,  1899,  1932,  1965,
    1998,  3204,  2031,  3216,  2064,  3227,  3328,   175,   377,   383,
     105,    -4,  1253,   135,  2856,   445,  2097,   169,   245,   924,
     332,  1327,  1327,   379,   379,   380,  1226,   445,  1534,  3239,
     420,  3339,   423,  2130,  2163,   -16,  1359,  1359,  1183,  1183,
    1183,  2196,  2229,   424,  3250,   128,  2262,    18,   432,   209,
     429,  2295,   456,   152,   457,   180,   458,   234,   524,   440,
     463,   467,   476,  3262,   107,   190,   259,  1012,  1212,  1409,
    1411,   705,  3319,  3273,  2889,   486,  1359,  2922,   483,   484,
     487,   488,   495,   501,   512,   -12,  3285,  2922,  1490,  1461,
    3296,  2328,  1542,  2361,  2394,  2427,  2460,  2493,  2526,   514,
     521,  2559,   108,   135,   185,   135,  2974,   535,   539,  2986,
    2997,  1401,   977,  3009,   999,   189,  1089,    57,   117,  3020,
    3032,  3043,  3055,  3446,  3308,   255,  2592,  2625,   135,  1249,
     547,   549,  3331,  3342,  1538,  1025,  3354,   533,   536,   286,
     361,   627,  3358,  3366,   391,  3370,  3382,  3393,   135,   288,
     564,   569,   291,   304,   113,  1084,   343,   737,   147,  1157,
     563,   889,   453,   490,  1221,   702,   761,   841,  2658,   580,
     581,  1449,   272,  2691,  2724,   582,   583,   204,   379,   557,
    1244,   135,  1621,  3066,  1642,  1642,  1589,  1589,  1589,   588,
     591,  1294,  1511,    77,   602,  2757,   205,   379,   577,  1290,
    1327,  1625,  3405,  1327,  1327,  2954,  2954,  2954,   225,   379,
     587,  1413,  1461,   201,   864,  2946,  2946,  2966,  2966,  2966,
    1327,  1327,   634,   635,  1500,  1609,  2790,   638,  1327,  1327,
    3078,   642,   644,  3089,   282,   235,  1466,  1651,  1710,   987,
     465,  3101,  1327,  1327,   661,  3409,   648,   650,  3417,   305,
     493,   630,   630,   286,   286,  1517,  1593,  3421,   899,   653,
     657,   902,   334,   176,   155,   646,  1668,  1713,  1106,   912,
    1030,  2950,  2999,  1327,  1327,  2823,  3091,  3456,  3112,  3467,
    3124,  3469,  3479,  3433,   542,  3444,   310,  1072,  3022,  1162,
    3516,  3519,  3485,  3488,   669,   687,  3490,  3506,   690,   693,
     603,   607,  3045,  3068,  1327,  1327,  3508,  3511,   689,   692
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     1,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -219,  -219,   451,  -219,  -219,   676,  -219,  -219,   682,     7,
     -24,   -80,   -78,  -219,  -103,  -219,   325,   799,   -93,  -219,
    1315,  1494,  1096,   749,   537,   260,   472,  -219,  1363,  -219,
    -219,  -219,  -218,  -219,  -219,  -219,   -30,  -219,  1048,   407,
     111
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     6,     7,     8,     9,    24,    18,    19,    20,    48,
      49,    50,    51,    52,    53,    54,    55,    56,   130,    57,
     207,   208,   209,    61,    62,    63,    64,    65,   214,    67,
     120,    68,   135,    69,    84,    70,    71,    72,   216,    74,
      75
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     191,   131,   138,   -50,   117,    79,   197,    10,   239,   240,
     -50,   -50,   245,   246,   -18,    10,   137,    99,    10,   -22,
     169,    21,   -22,   -22,   -22,   -50,   -19,   102,   -22,   -22,
     145,   -22,   304,    21,   -22,   -22,   -22,   -22,   -22,   -22,
     -22,   -22,   -22,   -22,   -22,   -22,   -22,   104,   -22,   -22,
     -22,   319,   170,   191,   -22,   -45,   -17,   -16,   191,   191,
     116,   215,   215,   332,   -48,   161,   235,   244,   105,   197,
      26,   -48,   -48,    12,   -12,    -2,   -45,   244,   -24,   197,
      15,   -24,   -24,   -24,    14,    -4,   -48,   -24,   -24,   -24,
     -24,   256,   262,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,    -5,   -24,   -24,   -24,
     -73,   -72,   114,   -24,   -73,   -72,   -79,   244,   281,   197,
     -79,   -14,   282,   163,   -53,   -14,   -15,   -79,   -79,   235,
     -15,   -53,   -53,   171,   195,   144,   242,   242,    23,   295,
     175,   192,   -79,   191,    25,   191,   -53,   -79,   -79,   -79,
     -45,   -53,   253,   257,   -45,   301,   176,   195,   -79,   149,
     281,   177,   -79,   178,   270,   179,   180,   181,   191,   -79,
     -79,   182,   264,   265,   316,   272,   -45,   121,   -13,   -47,
      27,   195,   -13,   -47,   -79,   100,   329,   151,   191,   -79,
     -79,   -79,   -66,   159,   192,   284,   -45,   160,   105,   192,
     192,     1,   217,   217,   -79,   242,   281,   237,   -79,   195,
       2,   300,   315,     3,   -45,   -79,   -79,   146,   -45,   297,
     235,   191,     4,     5,   191,   191,   191,   191,   191,    83,
     -79,    85,   328,   195,   195,   -79,   -79,   -79,   -45,   235,
     215,   153,   -47,   215,   215,   215,   215,   215,   -49,   -49,
     175,   235,   235,   371,   195,   235,   235,   235,   235,   235,
     215,   215,    -9,   -49,   195,    22,   176,   -47,   215,   215,
     237,   177,    88,   178,    89,   179,   180,   181,   122,   259,
     260,   182,   215,   215,   192,   159,   192,   261,   105,   350,
     189,   -89,    90,   192,   -87,   -89,   292,   293,   -87,    91,
     273,   274,   -89,   -89,   294,   -87,   -87,   -88,   159,   192,
     103,   -88,   355,   215,   215,   -46,   217,   -89,   -88,   -88,
     -87,    38,   -89,   -89,   -89,   -87,   -87,   -87,    92,   192,
      44,    45,    98,   -88,   368,   369,   237,   159,   -88,   -88,
     -88,   359,   370,   189,   215,   215,   -62,    93,   189,   189,
     -62,   212,   212,   -49,    94,   183,   232,   -62,   -62,   -49,
     -49,   237,   192,    95,   126,   192,   192,   192,   192,   192,
     143,   101,   -62,   -22,   -49,   -48,   -48,   -62,   -62,   -62,
     237,   217,   -85,   -24,   217,   217,   217,   217,   217,   113,
     -48,   -85,   237,   237,   -85,   275,   237,   237,   237,   237,
     237,   217,   217,   -85,   -85,   -50,   -50,    11,   183,   217,
     217,   129,   132,   183,   183,    11,   206,   206,    11,   232,
     -50,   226,    28,   217,   217,    29,    30,    31,   238,   -20,
     -23,     2,    32,   189,     3,   189,   147,    33,    34,    35,
      36,    37,    38,     4,     5,    39,    40,    41,    42,    43,
      30,    44,    45,    46,   217,   217,   -55,    47,   189,    13,
     -55,   105,    16,   148,   150,   152,    38,   -55,   -55,   155,
     156,    41,   -56,    43,   157,    44,    45,    46,   189,   -56,
     -56,    47,   -55,   158,   226,   217,   217,   -55,   289,   -55,
     243,   164,   165,   -57,   -56,   166,   167,   -57,   183,   -56,
     183,   -56,   190,   168,   -57,   -57,   -48,   -49,   -49,   -36,
     232,   189,   -48,   -48,   189,   189,   189,   189,   311,   -57,
     -37,   -43,   -49,   183,   -57,   -57,   -57,   -48,   -42,   232,
     212,   154,   108,   212,   212,   212,   212,   327,   -49,   -49,
     248,   232,   232,   183,   249,   232,   232,   232,   232,   340,
     212,   212,   267,   -49,   268,   190,   -64,   -64,   212,   212,
     190,   190,   195,   213,   213,   -45,   -48,   188,   233,   279,
     -48,   -64,   212,   212,   280,   226,   183,   -48,   -48,   183,
     183,   183,   183,   183,   -46,   290,   291,   298,   299,   302,
     106,   107,   -48,   312,   226,   206,   313,   287,   206,   206,
     206,   206,   206,   212,   212,   -46,   226,   226,   314,   317,
     226,   226,   226,   226,   226,   206,   206,   -41,   -41,   330,
     188,   -40,   -40,   206,   206,   188,   188,    30,   211,   211,
      86,   233,   -41,   231,   212,   212,   -40,   206,   206,   343,
     344,   -53,   -53,    38,   345,   190,   142,   190,    41,   348,
      43,   349,    44,    45,    46,   353,   -53,   354,    47,   356,
     357,   -53,   -23,   276,   358,   -23,   -23,   -23,   206,   206,
     190,   -23,   -23,   -23,   -23,   242,   -36,   -23,   -23,   -23,
     -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,
     190,   -23,   -23,   -23,   -37,   374,   231,   -23,   375,   206,
     206,    76,     0,   -36,   -36,   -60,   -37,   -37,    77,   -60,
     188,     0,   188,   -54,     0,     0,   -60,   -60,   -36,   -54,
     -54,   -37,   233,   190,     0,     0,   190,   190,   190,   190,
     190,   -60,     0,     0,   -54,   188,   -60,   -60,   -60,   -54,
     -49,   233,   213,     0,   -49,   213,   213,   213,   213,   213,
       0,   -49,   -49,   233,   233,   188,     0,   233,   233,   233,
     233,   233,   213,   213,   -81,     0,   -49,     0,   -81,     2,
     213,   213,     3,     0,     0,   -81,   -81,     0,     0,   187,
       0,     4,     5,    17,   213,   213,     2,   231,   188,     3,
     -81,   188,   188,   188,   310,   -81,   -81,   -81,     4,     5,
       0,     0,     0,     0,     0,     0,   231,   211,     0,     0,
     211,   211,   211,   326,     0,   213,   213,     0,   231,   231,
      -8,    -8,   231,   231,   231,   339,     0,   211,   211,   184,
      -8,     0,   187,    -8,     0,   211,   211,   187,   187,     0,
     210,   210,    -8,    -8,   -80,   230,   213,   213,   -80,   211,
     211,    -3,     1,     0,     0,   -80,   -80,   141,     0,     0,
       0,     2,   111,     0,     3,     0,     0,   -61,   -50,   -50,
     -80,   -61,     0,     4,     5,   -80,   -80,   -80,   -61,   -61,
     211,   211,   184,   -50,     0,     0,     0,   184,   184,     0,
     127,   128,   -53,   -61,     0,   227,   -53,     0,   -61,   -61,
     -61,     0,   -59,   -53,   -53,   -84,   -59,     0,   230,   -84,
       0,   211,   211,   -59,   -59,   -56,   -84,   -84,   -53,   -56,
       0,     0,   187,   -53,   187,   288,   -56,   -56,   -59,   175,
       0,   -84,     0,   -59,   -59,   -59,   -84,   -84,   -84,     0,
       0,   -56,     0,     0,     0,   176,   -56,   187,   -56,     0,
     177,     0,   178,     0,   179,   180,   181,   124,   227,     0,
     182,   -86,     0,     0,   -86,   -86,   -86,   187,     0,     0,
     -86,   -86,   184,   -86,   184,     0,   -86,   -86,   -86,   -86,
     -86,   -86,   -86,   -86,   -86,   -86,   -86,   -86,   -86,     0,
     -86,   -86,   -86,     0,   -54,     0,   -86,   184,   176,   230,
     187,   -54,   -54,   187,   187,   309,   -49,   179,   180,   252,
       0,     0,     0,   -49,   -49,     0,   -54,   184,   230,   210,
     -41,   -54,   210,   210,   325,     0,   -41,   -41,   -49,     0,
     230,   230,     0,   -58,   230,   230,   338,   -58,     0,   210,
     210,   -41,     0,     0,   -58,   -58,   199,   210,   210,   227,
     184,     0,     0,   184,   184,   202,   203,   271,     0,   -58,
       0,   210,   210,     0,   -58,   -58,   -58,     0,   227,   320,
       0,    73,   320,   320,     0,   -39,     0,    73,    82,   -39,
     227,   227,   194,     0,   227,   227,   -39,   -39,     0,   341,
     342,     0,   210,   210,     0,   194,   -46,   346,   347,    73,
       0,   -39,     0,   254,   255,   219,   -39,   -39,   -39,   -54,
       0,   351,   352,   -54,   222,   223,   283,     0,   -46,    60,
     -54,   -54,     0,   210,   210,    60,   186,     0,    -7,    -7,
      60,    82,    73,   194,     0,   -54,    82,    82,    -7,     0,
     -54,    -7,   362,   363,   236,   194,     0,    60,     0,     0,
      -7,    -7,     0,     0,   194,   194,   194,   194,   194,     0,
     -46,   -53,     0,     0,   -46,   -83,     0,   -53,   -53,   -83,
       0,   285,   286,   376,   377,     0,   -83,   -83,     0,   186,
      60,    60,   -53,     0,   186,   186,   -46,   -53,    30,   109,
       0,   -83,   229,    60,   194,    73,   -83,   -83,   -83,     0,
       0,     0,   139,   140,    38,    73,     0,   236,    96,    41,
       0,   -79,    97,    44,    45,    98,     0,   -79,   -79,    47,
     -40,    82,     0,    82,   -50,     0,   -40,   -40,   -50,     0,
      82,   218,   -79,   133,     0,   -50,   -50,   -79,   -79,   -79,
       0,   -40,   162,    60,    73,    73,    82,   219,     0,   218,
     -50,   303,   220,    60,   221,   229,   222,   223,   224,     0,
     -81,     0,   225,   -89,   -89,   219,    82,   -81,   -81,   186,
     220,   186,   221,   236,   222,   223,   224,     0,   -89,     0,
     225,     0,   -81,   -89,   -89,   -89,     0,   -81,   -81,   -81,
       0,    73,    60,    60,   186,   218,     0,   318,   236,    82,
       0,   -41,    82,    82,    82,    82,    82,     0,   -41,   -41,
       0,   219,     0,     0,   186,     0,   220,   236,   221,     0,
     222,   223,   224,   -41,     0,     0,   225,     0,     0,   236,
     236,     0,   198,   236,   236,   236,   236,   236,    58,    60,
       0,     0,     0,     0,    58,    80,   229,   186,   199,    87,
     307,   308,     0,   200,     0,   201,     0,   202,   203,   204,
       0,   -11,   -11,   205,    30,   229,    58,     0,     0,   323,
     324,   -11,     0,     0,   -11,     0,     0,   229,   229,     0,
      38,   336,   337,   -11,   -11,    41,    66,    43,     0,    44,
      45,   241,    66,    81,     0,    47,     0,   193,   115,    58,
     118,     0,     0,   123,   125,     0,   250,     0,   -79,     0,
     251,   134,   136,     0,    66,   -79,   -79,   -51,   218,   -52,
     331,   118,   118,   106,   107,   106,   107,     0,     0,     0,
     -79,     0,     0,     0,   219,   -79,   -79,   -79,   -46,   220,
     -46,   221,     0,   222,   223,   224,    81,    66,   193,   225,
       0,    81,    81,     0,    96,     0,     0,   -79,   270,   234,
     193,   118,    58,   -79,   -79,     0,   218,     0,     0,   193,
     193,   250,    58,   -79,   172,   270,     0,     0,   -79,     0,
     -79,   -79,   219,   -79,   -79,   -79,     0,   220,     0,   221,
     247,   222,   223,   224,     0,   -79,     0,   225,   -64,     0,
     -79,   -79,   -79,   -41,   -64,   -64,     0,   -41,     0,   193,
      66,    58,    58,   266,   -41,   -41,     0,    59,   -40,   -64,
      66,     0,   234,    59,   185,   -40,   -40,     0,    59,   -41,
       0,   -54,   -54,   278,     0,     0,    81,     0,    81,    96,
     -40,     0,   -79,   269,     0,    59,   -54,   270,   -79,   -79,
     173,   -54,   -79,   -79,     0,     0,   106,   107,    58,    66,
      66,    81,     0,   -79,     0,   134,   305,   -79,   -79,   -79,
     -79,   -46,   -79,   -79,   -79,     0,     0,   185,    59,   119,
       0,    81,   185,   185,   134,   321,     0,     0,   322,   322,
     228,    59,     0,     0,   175,     0,   134,   333,     0,     0,
     335,   335,     0,     0,     0,     0,    66,   -56,   -56,     0,
     176,     0,   -40,   234,    81,   177,   -40,    81,    81,   179,
     180,   252,   -56,   -40,   -40,   182,   250,   -56,   -79,   -56,
     269,     0,   234,     0,     0,   -79,   -79,     0,   -40,   -79,
     -79,    59,     0,     0,   234,   234,     0,   175,   234,   234,
     -79,    59,     0,   228,   -79,   -79,   -79,   -79,   -51,   -79,
     -79,   -79,     0,   176,     0,   254,   255,   174,   177,   185,
     178,   -51,   179,   180,   306,   -51,     0,     0,   182,     0,
     -46,     0,   285,   286,    28,     0,     0,    29,    30,    78,
      59,    59,   185,     2,    32,     0,     3,   -46,     0,    33,
      34,    35,    36,    37,    38,     4,     5,    39,    40,    41,
      42,    43,   185,    44,    45,    46,   -52,   -52,     0,    47,
     -52,     0,     0,     0,   254,   255,     0,   285,   286,     0,
       0,    28,     0,     0,    29,    30,   -21,    59,     0,   -46,
       2,    32,   -46,     3,   228,   185,    33,    34,    35,    36,
      37,    38,     4,     5,    39,    40,    41,    42,    43,     0,
      44,    45,    46,   228,     0,     0,    47,     0,   -33,     0,
       0,   -33,   -33,   -33,     0,   228,   228,   -33,   -33,     0,
     -33,     0,     0,   -33,   -33,   -33,   -33,   -33,   -33,   -33,
     -33,   -33,   -33,   -33,   -33,   -33,     0,   -33,   -33,   -33,
       0,   -35,     0,   -33,   -35,   -35,   -35,     0,     0,     0,
     -35,   -35,     0,   -35,     0,     0,   -35,   -35,   -35,   -35,
     -35,   -35,   -35,   -35,   -35,   -35,   -35,   -35,   -35,     0,
     -35,   -35,   -35,     0,   -31,     0,   -35,   -31,   -31,   -31,
       0,     0,     0,   -31,   -31,     0,   -31,     0,     0,   -31,
     -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,
     -31,   -31,     0,   -31,   -31,   -31,     0,   -29,     0,   -31,
     -29,   -29,   -29,     0,     0,     0,   -29,   -29,     0,   -29,
       0,     0,   -29,   -29,   -29,   -29,   -29,   -29,   -29,   -29,
     -29,   -29,   -29,   -29,   -29,     0,   -29,   -29,   -29,     0,
     -28,     0,   -29,   -28,   -28,   -28,     0,     0,     0,   -28,
     -28,     0,   -28,     0,     0,   -28,   -28,   -28,   -28,   -28,
     -28,   -28,   -28,   -28,   -28,   -28,   -28,   -28,     0,   -28,
     -28,   -28,     0,   -32,     0,   -28,   -32,   -32,   -32,     0,
       0,     0,   -32,   -32,     0,   -32,     0,     0,   -32,   -32,
     -32,   -32,   -32,   -32,   -32,   -32,   -32,   -32,   -32,   -32,
     -32,     0,   -32,   -32,   -32,     0,   -27,     0,   -32,   -27,
     -27,   -27,     0,     0,     0,   -27,   -27,     0,   -27,     0,
       0,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,
     -27,   -27,   -27,   -27,     0,   -27,   -27,   -27,     0,   -26,
       0,   -27,   -26,   -26,   -26,     0,     0,     0,   -26,   -26,
       0,   -26,     0,     0,   -26,   -26,   -26,   -26,   -26,   -26,
     -26,   -26,   -26,   -26,   -26,   -26,   -26,     0,   -26,   -26,
     -26,     0,   -30,     0,   -26,   -30,   -30,   -30,     0,     0,
       0,   -30,   -30,     0,   -30,     0,     0,   -30,   -30,   -30,
     -30,   -30,   -30,   -30,   -30,   -30,   -30,   -30,   -30,   -30,
       0,   -30,   -30,   -30,     0,   -25,     0,   -30,   -25,   -25,
     -25,     0,     0,     0,   -25,   -25,     0,   -25,     0,     0,
     -25,   -25,   -25,   -25,   -25,   -25,   -25,   -25,   -25,   -25,
     -25,   -25,   -25,     0,   -25,   -25,   -25,     0,   -78,     0,
     -25,   -78,   -78,   -78,     0,     0,     0,   -78,   -78,     0,
     -78,     0,     0,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,     0,   -78,   -78,   -78,
       0,   -34,     0,   -78,   -34,   -34,   -34,     0,     0,     0,
     -34,   -34,     0,   -34,     0,     0,   -34,   -34,   -34,   -34,
     -34,   -34,   -34,   -34,   -34,   -34,   -34,   -34,   -34,     0,
     -34,   -34,   -34,     0,   -44,     0,   -34,   -44,   -44,   -44,
       0,     0,     0,   -44,   -44,     0,   -44,     0,     0,   -44,
     -44,   -44,   -44,   -44,   -44,   -44,   -44,   -44,   -44,   -44,
     -44,   -44,     0,   -44,   -44,   -44,     0,   -63,     0,   -44,
     -63,   -63,   -63,     0,     0,     0,   -63,   -63,     0,   -63,
       0,     0,   -63,   -63,   -63,   -63,   -63,   -63,   -63,   -63,
     -63,   -63,   -63,   -63,   -63,     0,   -63,   -63,   -63,     0,
     -82,     0,   -63,   -82,   -82,   -82,     0,     0,     0,   -82,
     -82,     0,   -82,     0,     0,   -82,   -82,   -82,   -82,   -82,
     -82,   -82,   -82,   -82,   -82,   -82,   -82,   -82,     0,   -82,
     -82,   -82,     0,   -74,     0,   -82,   -74,   -74,   -74,     0,
       0,     0,   -74,   -74,     0,   -74,     0,     0,   -74,   -74,
     -74,   -74,   -74,   -74,   -74,   -74,   -74,   -74,   -74,   -74,
     -74,     0,   -74,   -74,   -74,     0,   -77,     0,   -74,   -77,
     -77,   -77,     0,     0,     0,   -77,   -77,     0,   -77,     0,
       0,   -77,   -77,   -77,   -77,   -77,   -77,   -77,   -77,   -77,
     -77,   -77,   -77,   -77,     0,   -77,   -77,   -77,     0,   -75,
       0,   -77,   -75,   -75,   -75,     0,     0,     0,   -75,   -75,
       0,   -75,     0,     0,   -75,   -75,   -75,   -75,   -75,   -75,
     -75,   -75,   -75,   -75,   -75,   -75,   -75,     0,   -75,   -75,
     -75,     0,   -65,     0,   -75,   -65,   -65,   -65,     0,     0,
       0,   -65,   -65,     0,   -65,     0,     0,   -65,   -65,   -65,
     -65,   -65,   -65,   -65,   -65,   -65,   -65,   -65,   -65,   -65,
       0,   -65,   -65,   -65,     0,   -68,     0,   -65,   -68,   -68,
     -68,     0,     0,     0,   -68,   -68,     0,   -68,     0,     0,
     -68,   -68,   -68,   -68,   -68,   -68,   -68,   -68,   -68,   -68,
     -68,   -68,   -68,     0,   -68,   -68,   -68,     0,   -69,     0,
     -68,   -69,   -69,   -69,     0,     0,     0,   -69,   -69,     0,
     -69,     0,     0,   -69,   -69,   -69,   -69,   -69,   -69,   -69,
     -69,   -69,   -69,   -69,   -69,   -69,     0,   -69,   -69,   -69,
       0,   -70,     0,   -69,   -70,   -70,   -70,     0,     0,     0,
     -70,   -70,     0,   -70,     0,     0,   -70,   -70,   -70,   -70,
     -70,   -70,   -70,   -70,   -70,   -70,   -70,   -70,   -70,     0,
     -70,   -70,   -70,     0,   -71,     0,   -70,   -71,   -71,   -71,
       0,     0,     0,   -71,   -71,     0,   -71,     0,     0,   -71,
     -71,   -71,   -71,   -71,   -71,   -71,   -71,   -71,   -71,   -71,
     -71,   -71,     0,   -71,   -71,   -71,     0,   -67,     0,   -71,
     -67,   -67,   -67,     0,     0,     0,   -67,   -67,     0,   -67,
       0,     0,   -67,   -67,   -67,   -67,   -67,   -67,   -67,   -67,
     -67,   -67,   -67,   -67,   -67,     0,   -67,   -67,   -67,     0,
     -38,     0,   -67,   -38,   -38,   -38,     0,     0,     0,   -38,
     -38,     0,   -38,     0,     0,   -38,   -38,   -38,   -38,   -38,
     -38,   -38,   -38,   -38,   -38,   -38,   -38,   -38,     0,   -38,
     -38,   -38,     0,    28,     0,   -38,    29,    30,   263,     0,
       0,     0,     2,    32,     0,     3,     0,     0,    33,    34,
      35,    36,    37,    38,     4,     5,    39,    40,    41,    42,
      43,     0,    44,    45,    46,     0,    28,     0,    47,   243,
      30,   -21,     0,     0,     0,     2,    32,     0,     3,     0,
       0,    33,    34,    35,    36,    37,    38,     4,     5,    39,
      40,    41,    42,    43,     0,    44,    45,    46,     0,   -85,
       0,    47,   -85,   -85,   -85,     0,     0,     0,   -85,   -85,
       0,   -85,     0,     0,   -85,   -85,   -85,   -85,   -85,   -85,
     -85,   -85,   -85,   -85,   -85,   -85,   -85,     0,   -85,   -85,
     -85,     0,    28,     0,   -85,    29,    30,   296,     0,     0,
       0,     2,    32,     0,     3,     0,     0,    33,    34,    35,
      36,    37,    38,     4,     5,    39,    40,    41,    42,    43,
       0,    44,    45,    46,     0,   -22,     0,    47,   -22,   -22,
     -22,     0,     0,     0,   -22,   -22,     0,   -22,     0,     0,
     -22,   -22,   -22,   -22,   -22,   -22,   -22,   -22,   -22,   -22,
     -22,   -22,   -22,     0,   -22,   -22,   -22,     0,   -20,     0,
     -22,   -20,   -20,   -20,     0,     0,     0,   -20,   -20,     0,
     -20,     0,     0,   -20,   -20,   -20,   -20,   -20,   -20,   -20,
     -20,   -20,   -20,   -20,   -20,   -20,     0,   -20,   -20,   -20,
       0,   -24,     0,   -20,   -24,   -24,   -24,     0,     0,     0,
     -24,   -24,     0,   -24,     0,     0,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,     0,
     -24,   -24,   -24,     0,   -23,     0,   -24,   -23,   -23,   -23,
       0,     0,     0,   -23,   -23,     0,   -23,     0,     0,   -23,
     -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,
     -23,   -23,     0,   -23,   -23,   -23,     0,    28,     0,   -23,
     196,    30,     0,     0,     0,     0,     2,    32,     0,     3,
       0,     0,    33,    34,    35,    36,    37,    38,     4,     5,
      39,    40,    41,    42,    43,     0,    44,    45,    46,     0,
     -76,     0,    47,   -76,   -76,     0,     0,     0,     0,   -76,
     -76,     0,   -76,     0,     0,   -76,   -76,   -76,   -76,   -76,
     -76,   -76,   -76,   -76,   -76,   -76,   -76,   -76,     0,   -76,
     -76,   -76,     0,    28,     0,   -76,   243,    30,     0,     0,
       0,     0,     2,    32,     0,     3,     0,     0,    33,    34,
      35,    36,    37,    38,     4,     5,    39,    40,    41,    42,
      43,   218,    44,    45,    46,     0,     0,   360,    47,   198,
       0,     0,     0,     0,   -49,   -49,     0,   219,     0,     0,
       0,   218,   220,     0,   221,   199,   222,   223,   334,   -49,
     200,   -89,   225,     0,   202,   203,   271,   219,   -89,   -89,
     205,     0,   220,   -87,     0,     0,   222,   223,   283,     0,
     -87,   -87,   225,   -89,   -88,     0,   361,     0,   -89,   -89,
     -89,   -88,   -88,   -49,   -49,   -87,   -62,     0,     0,     0,
     -87,   -87,   -87,   -62,   -62,   -64,   -88,   -55,   -49,   -64,
       0,   -88,   -88,   -88,   -55,   -55,   -64,   -64,   -62,   -57,
       0,     0,     0,   -62,   -62,   -62,   -57,   -57,   -36,   -55,
     -60,   -64,   -36,     0,   -55,   258,   -55,   -60,   -60,   -36,
     -36,   -57,   -80,     0,     0,     0,   -57,   -57,   -57,   -80,
     -80,   -37,   -60,   -61,   -36,   -37,     0,   -60,   -60,   -60,
     -61,   -61,   -37,   -37,   -80,   -59,     0,     0,     0,   -80,
     -80,   -80,   -59,   -59,     0,   -61,   -84,   -37,   364,     0,
     -61,   -61,   -61,   -84,   -84,   -49,   -49,   -59,   -58,     0,
       0,     0,   -59,   -59,   -59,   -58,   -58,     0,   -84,   -39,
     -49,     0,     0,   -84,   -84,   -84,   -39,   -39,     0,     0,
     -58,   -83,     0,     0,     0,   -58,   -58,   -58,   -83,   -83,
       0,   -39,     0,   -89,     0,     0,   -39,   -39,   -39,   -89,
     -89,     0,     0,   -83,     0,   -87,     0,     0,   -83,   -83,
     -83,   -87,   -87,     0,   -89,     0,   -88,     0,     0,   -89,
     -89,   -89,   -88,   -88,     0,     0,   -87,     0,   -62,     0,
       0,   -87,   -87,   -87,   -62,   -62,     0,   -88,     0,   -55,
       0,     0,   -88,   -88,   -88,   -55,   -55,     0,     0,   -62,
       0,   -57,     0,     0,   -62,   -62,   -62,   -57,   -57,     0,
     -55,     0,   -60,     0,     0,   -55,   110,   -55,   -60,   -60,
       0,     0,   -57,     0,   112,     0,     0,   -57,   -57,   -57,
     -81,   -81,     0,   -60,     0,   -80,     0,     0,   -60,   -60,
     -60,   -80,   -80,     0,     0,   -81,     0,   -61,     0,     0,
     -81,   -81,   -81,   -61,   -61,     0,   -80,     0,   -59,     0,
       0,   -80,   -80,   -80,   -59,   -59,     0,     0,   -61,     0,
     -84,     0,     0,   -61,   -61,   -61,   -84,   -84,     0,   -59,
       0,   -58,     0,     0,   -59,   -59,   -59,   -58,   -58,     0,
       0,   -84,     0,   -39,     0,     0,   -84,   -84,   -84,   -39,
     -39,     0,   -58,     0,   -83,     0,     0,   -58,   -58,   -58,
     -83,   -83,     0,     0,   -39,     0,   -81,     0,     0,   -39,
     -39,   -39,   -81,   -81,     0,   -83,     0,   -56,    -6,    -6,
     -83,   -83,   -83,   -56,   -56,     0,     0,   -81,    -6,   -10,
     -10,    -6,   -81,   -81,   -81,   -87,   -87,     0,   -56,   -10,
      -6,    -6,   -10,   -56,     0,   -56,   -88,   -88,     0,     0,
     -87,   -10,   -10,     0,     0,   -87,   -87,   -87,   -62,   -62,
       0,   -88,   -55,   -55,     0,     0,   -88,   -88,   -88,     0,
     -57,   -57,     0,   -62,   -60,   -60,     0,   -55,   -62,   -62,
     -62,     0,   -55,   277,   -55,   -57,   -81,   -81,     0,   -60,
     -57,   -57,   -57,     0,   -60,   -60,   -60,   -80,   -80,     0,
       0,   -81,     0,     0,     0,     0,   -81,   -81,   -81,   -61,
     -61,     0,   -80,   -59,   -59,     0,     0,   -80,   -80,   -80,
       0,   -84,   -84,     0,   -61,   -58,   -58,     0,   -59,   -61,
     -61,   -61,     0,   -59,   -59,   -59,   -84,   -39,   -39,     0,
     -58,   -84,   -84,   -84,   -50,   -58,   -58,   -58,   -83,   -83,
     -50,   -50,   -39,   365,     0,     0,     0,   -39,   -39,   -39,
     -49,   -49,     0,   -83,   -64,   -50,   366,     0,   -83,   -83,
     -83,   -64,   -64,   -49,   -49,   -49,   367,     0,     0,     0,
       0,     0,   372,   -49,   -49,   373,   -64,   -36,   -49,   -49,
     -49,     0,   -49,   -49,   -36,   -36,     0,     0,   -49,     0,
       0,     0,     0,   -37,   -49,   378,     0,   -49,   379,   -36,
     -37,   -37,   -49,   -49,   -36,   -49,   -49,   -37,     0,     0,
     -36,   -36,     0,   -37,   -37,   -37,     0,   -49,     0,     0,
     -49,     0,     0,     0,     0,   -36,     0,     0,   -37
};

static const yytype_int16 yycheck[] =
{
      30,    94,   105,     7,    84,    29,    84,     0,    24,    25,
      14,    15,    24,    25,    32,     8,    32,    47,    11,     1,
      32,    14,     4,     5,     6,    29,    32,    51,    10,    11,
      12,    13,   250,    26,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,     8,    30,    31,
      32,   269,   155,    83,    36,     8,    32,    32,    88,    89,
      84,    91,    92,   281,     7,   145,    96,   147,    29,   147,
       3,    14,    15,     0,     7,     0,    29,   157,     1,   157,
      32,     4,     5,     6,     5,     0,    29,    10,    11,    12,
      13,    34,   195,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,     0,    30,    31,    32,
       3,     3,     7,    36,     7,     7,     3,   197,     5,   197,
       7,     3,     9,   147,     7,     7,     3,    14,    15,   159,
       7,    14,    15,   157,    29,     7,    29,    29,     4,   242,
       5,    30,    29,   173,     7,   175,    29,    34,    35,    36,
       3,    34,   182,    36,     7,   248,    21,    29,     3,     7,
       5,    26,     7,    28,     9,    30,    31,    32,   198,    14,
      15,    36,   196,   197,   267,   205,    29,     8,     3,     3,
      32,    29,     7,     7,    29,    32,   279,     7,   218,    34,
      35,    36,     7,     3,    83,   225,     7,     7,    29,    88,
      89,     1,    91,    92,     3,    29,     5,    96,     7,    29,
      10,     7,     7,    13,    29,    14,    15,     8,    29,   243,
     250,   251,    22,    23,   254,   255,   256,   257,   258,     5,
      29,     5,     7,    29,    29,    34,    35,    36,    29,   269,
     270,     7,     7,   273,   274,   275,   276,   277,    14,    15,
       5,   281,   282,   356,    29,   285,   286,   287,   288,   289,
     290,   291,     5,    29,    29,     8,    21,     8,   298,   299,
     159,    26,     5,    28,     5,    30,    31,    32,    33,    24,
      25,    36,   312,   313,   173,     3,   175,    32,    29,     7,
      30,     3,     5,   182,     3,     7,    24,    25,     7,     5,
      14,    15,    14,    15,    32,    14,    15,     3,     3,   198,
       8,     7,     7,   343,   344,    29,   205,    29,    14,    15,
      29,    21,    34,    35,    36,    34,    35,    36,     5,   218,
      30,    31,    32,    29,    24,    25,   225,     3,    34,    35,
      36,     7,    32,    83,   374,   375,     3,     5,    88,    89,
       7,    91,    92,     8,     5,    30,    96,    14,    15,    14,
      15,   250,   251,     5,    32,   254,   255,   256,   257,   258,
     110,     6,    29,     6,    29,    14,    15,    34,    35,    36,
     269,   270,     1,     6,   273,   274,   275,   276,   277,     6,
      29,    10,   281,   282,    13,    34,   285,   286,   287,   288,
     289,   290,   291,    22,    23,    14,    15,     0,    83,   298,
     299,    32,    32,    88,    89,     8,    91,    92,    11,   159,
      29,    96,     1,   312,   313,     4,     5,     6,     8,     6,
       6,    10,    11,   173,    13,   175,     7,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
       5,    30,    31,    32,   343,   344,     3,    36,   198,     8,
       7,    29,    11,     7,     7,     7,    21,    14,    15,    29,
       7,    26,     7,    28,     7,    30,    31,    32,   218,    14,
      15,    36,    29,     7,   159,   374,   375,    34,    35,    36,
       4,     8,     8,     3,    29,     8,     8,     7,   173,    34,
     175,    36,    30,     8,    14,    15,     8,    14,    15,     8,
     250,   251,    14,    15,   254,   255,   256,   257,   258,    29,
       8,     7,    29,   198,    34,    35,    36,    29,     7,   269,
     270,     7,    34,   273,   274,   275,   276,   277,    14,    15,
       5,   281,   282,   218,     5,   285,   286,   287,   288,   289,
     290,   291,     5,    29,     5,    83,    14,    15,   298,   299,
      88,    89,    29,    91,    92,    29,     3,    30,    96,     5,
       7,    29,   312,   313,     5,   250,   251,    14,    15,   254,
     255,   256,   257,   258,     8,     5,     5,     5,     5,    32,
      14,    15,    29,     5,   269,   270,     5,    34,   273,   274,
     275,   276,   277,   343,   344,    29,   281,   282,     6,    32,
     285,   286,   287,   288,   289,   290,   291,    14,    15,    32,
      83,    14,    15,   298,   299,    88,    89,     5,    91,    92,
       8,   159,    29,    96,   374,   375,    29,   312,   313,     5,
       5,    14,    15,    21,     6,   173,   109,   175,    26,     7,
      28,     7,    30,    31,    32,     7,    29,     7,    36,    29,
       7,    34,     1,    36,     7,     4,     5,     6,   343,   344,
     198,    10,    11,    12,    13,    29,     7,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
     218,    30,    31,    32,     7,     5,   159,    36,     5,   374,
     375,    25,    -1,    14,    15,     3,    14,    15,    26,     7,
     173,    -1,   175,     8,    -1,    -1,    14,    15,    29,    14,
      15,    29,   250,   251,    -1,    -1,   254,   255,   256,   257,
     258,    29,    -1,    -1,    29,   198,    34,    35,    36,    34,
       3,   269,   270,    -1,     7,   273,   274,   275,   276,   277,
      -1,    14,    15,   281,   282,   218,    -1,   285,   286,   287,
     288,   289,   290,   291,     3,    -1,    29,    -1,     7,    10,
     298,   299,    13,    -1,    -1,    14,    15,    -1,    -1,    30,
      -1,    22,    23,     7,   312,   313,    10,   250,   251,    13,
      29,   254,   255,   256,   257,    34,    35,    36,    22,    23,
      -1,    -1,    -1,    -1,    -1,    -1,   269,   270,    -1,    -1,
     273,   274,   275,   276,    -1,   343,   344,    -1,   281,   282,
       0,     1,   285,   286,   287,   288,    -1,   290,   291,    30,
      10,    -1,    83,    13,    -1,   298,   299,    88,    89,    -1,
      91,    92,    22,    23,     3,    96,   374,   375,     7,   312,
     313,     0,     1,    -1,    -1,    14,    15,   108,    -1,    -1,
      -1,    10,     8,    -1,    13,    -1,    -1,     3,    14,    15,
      29,     7,    -1,    22,    23,    34,    35,    36,    14,    15,
     343,   344,    83,    29,    -1,    -1,    -1,    88,    89,    -1,
      91,    92,     3,    29,    -1,    96,     7,    -1,    34,    35,
      36,    -1,     3,    14,    15,     3,     7,    -1,   159,     7,
      -1,   374,   375,    14,    15,     3,    14,    15,    29,     7,
      -1,    -1,   173,    34,   175,    36,    14,    15,    29,     5,
      -1,    29,    -1,    34,    35,    36,    34,    35,    36,    -1,
      -1,    29,    -1,    -1,    -1,    21,    34,   198,    36,    -1,
      26,    -1,    28,    -1,    30,    31,    32,    33,   159,    -1,
      36,     1,    -1,    -1,     4,     5,     6,   218,    -1,    -1,
      10,    11,   173,    13,   175,    -1,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    31,    32,    -1,     7,    -1,    36,   198,    21,   250,
     251,    14,    15,   254,   255,   256,     7,    30,    31,    32,
      -1,    -1,    -1,    14,    15,    -1,    29,   218,   269,   270,
       8,    34,   273,   274,   275,    -1,    14,    15,    29,    -1,
     281,   282,    -1,     3,   285,   286,   287,     7,    -1,   290,
     291,    29,    -1,    -1,    14,    15,    21,   298,   299,   250,
     251,    -1,    -1,   254,   255,    30,    31,    32,    -1,    29,
      -1,   312,   313,    -1,    34,    35,    36,    -1,   269,   270,
      -1,    23,   273,   274,    -1,     3,    -1,    29,    30,     7,
     281,   282,    34,    -1,   285,   286,    14,    15,    -1,   290,
     291,    -1,   343,   344,    -1,    47,     7,   298,   299,    51,
      -1,    29,    -1,    14,    15,    21,    34,    35,    36,     3,
      -1,   312,   313,     7,    30,    31,    32,    -1,    29,    23,
      14,    15,    -1,   374,   375,    29,    30,    -1,     0,     1,
      34,    83,    84,    85,    -1,    29,    88,    89,    10,    -1,
      34,    13,   343,   344,    96,    97,    -1,    51,    -1,    -1,
      22,    23,    -1,    -1,   106,   107,   108,   109,   110,    -1,
       3,     8,    -1,    -1,     7,     3,    -1,    14,    15,     7,
      -1,    14,    15,   374,   375,    -1,    14,    15,    -1,    83,
      84,    85,    29,    -1,    88,    89,    29,    34,     5,    36,
      -1,    29,    96,    97,   146,   147,    34,    35,    36,    -1,
      -1,    -1,   106,   107,    21,   157,    -1,   159,     5,    26,
      -1,     8,     9,    30,    31,    32,    -1,    14,    15,    36,
       8,   173,    -1,   175,     3,    -1,    14,    15,     7,    -1,
     182,     5,    29,     7,    -1,    14,    15,    34,    35,    36,
      -1,    29,   146,   147,   196,   197,   198,    21,    -1,     5,
      29,     7,    26,   157,    28,   159,    30,    31,    32,    -1,
       7,    -1,    36,    14,    15,    21,   218,    14,    15,   173,
      26,   175,    28,   225,    30,    31,    32,    -1,    29,    -1,
      36,    -1,    29,    34,    35,    36,    -1,    34,    35,    36,
      -1,   243,   196,   197,   198,     5,    -1,     7,   250,   251,
      -1,     7,   254,   255,   256,   257,   258,    -1,    14,    15,
      -1,    21,    -1,    -1,   218,    -1,    26,   269,    28,    -1,
      30,    31,    32,    29,    -1,    -1,    36,    -1,    -1,   281,
     282,    -1,     5,   285,   286,   287,   288,   289,    23,   243,
      -1,    -1,    -1,    -1,    29,    30,   250,   251,    21,    34,
     254,   255,    -1,    26,    -1,    28,    -1,    30,    31,    32,
      -1,     0,     1,    36,     5,   269,    51,    -1,    -1,   273,
     274,    10,    -1,    -1,    13,    -1,    -1,   281,   282,    -1,
      21,   285,   286,    22,    23,    26,    23,    28,    -1,    30,
      31,    32,    29,    30,    -1,    36,    -1,    34,    83,    84,
      85,    -1,    -1,    88,    89,    -1,     5,    -1,     7,    -1,
       9,    96,    97,    -1,    51,    14,    15,     8,     5,     8,
       7,   106,   107,    14,    15,    14,    15,    -1,    -1,    -1,
      29,    -1,    -1,    -1,    21,    34,    35,    36,    29,    26,
      29,    28,    -1,    30,    31,    32,    83,    84,    85,    36,
      -1,    88,    89,    -1,     5,    -1,    -1,     8,     9,    96,
      97,   146,   147,    14,    15,    -1,     5,    -1,    -1,   106,
     107,     5,   157,     7,   159,     9,    -1,    -1,    29,    -1,
      14,    15,    21,    34,    35,    36,    -1,    26,    -1,    28,
     175,    30,    31,    32,    -1,    29,    -1,    36,     8,    -1,
      34,    35,    36,     3,    14,    15,    -1,     7,    -1,   146,
     147,   196,   197,   198,    14,    15,    -1,    23,     7,    29,
     157,    -1,   159,    29,    30,    14,    15,    -1,    34,    29,
      -1,    14,    15,   218,    -1,    -1,   173,    -1,   175,     5,
      29,    -1,     8,     5,    -1,    51,    29,     9,    14,    15,
       8,    34,    14,    15,    -1,    -1,    14,    15,   243,   196,
     197,   198,    -1,    29,    -1,   250,   251,    29,    34,    35,
      36,    29,    34,    35,    36,    -1,    -1,    83,    84,    85,
      -1,   218,    88,    89,   269,   270,    -1,    -1,   273,   274,
      96,    97,    -1,    -1,     5,    -1,   281,   282,    -1,    -1,
     285,   286,    -1,    -1,    -1,    -1,   243,    14,    15,    -1,
      21,    -1,     3,   250,   251,    26,     7,   254,   255,    30,
      31,    32,    29,    14,    15,    36,     5,    34,     7,    36,
       5,    -1,   269,    -1,    -1,    14,    15,    -1,    29,    14,
      15,   147,    -1,    -1,   281,   282,    -1,     5,   285,   286,
      29,   157,    -1,   159,    29,    34,    35,    36,     7,    34,
      35,    36,    -1,    21,    -1,    14,    15,   173,    26,   175,
      28,     3,    30,    31,    32,     7,    -1,    -1,    36,    -1,
      29,    -1,    14,    15,     1,    -1,    -1,     4,     5,     6,
     196,   197,   198,    10,    11,    -1,    13,    29,    -1,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,   218,    30,    31,    32,     3,     7,    -1,    36,
       7,    -1,    -1,    -1,    14,    15,    -1,    14,    15,    -1,
      -1,     1,    -1,    -1,     4,     5,     6,   243,    -1,    29,
      10,    11,    29,    13,   250,   251,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    31,    32,   269,    -1,    -1,    36,    -1,     1,    -1,
      -1,     4,     5,     6,    -1,   281,   282,    10,    11,    -1,
      13,    -1,    -1,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    30,    31,    32,
      -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,
      10,    11,    -1,    13,    -1,    -1,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    31,    32,    -1,     1,    -1,    36,     4,     5,     6,
      -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    30,    31,    32,    -1,     1,    -1,    36,
       4,     5,     6,    -1,    -1,    -1,    10,    11,    -1,    13,
      -1,    -1,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    30,    31,    32,    -1,
       1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,    10,
      11,    -1,    13,    -1,    -1,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    30,
      31,    32,    -1,     1,    -1,    36,     4,     5,     6,    -1,
      -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    30,    31,    32,    -1,     1,    -1,    36,     4,
       5,     6,    -1,    -1,    -1,    10,    11,    -1,    13,    -1,
      -1,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    30,    31,    32,    -1,     1,
      -1,    36,     4,     5,     6,    -1,    -1,    -1,    10,    11,
      -1,    13,    -1,    -1,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    30,    31,
      32,    -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,
      -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    30,    31,    32,    -1,     1,    -1,    36,     4,     5,
       6,    -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,    30,    31,    32,    -1,     1,    -1,
      36,     4,     5,     6,    -1,    -1,    -1,    10,    11,    -1,
      13,    -1,    -1,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    30,    31,    32,
      -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,
      10,    11,    -1,    13,    -1,    -1,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    31,    32,    -1,     1,    -1,    36,     4,     5,     6,
      -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    30,    31,    32,    -1,     1,    -1,    36,
       4,     5,     6,    -1,    -1,    -1,    10,    11,    -1,    13,
      -1,    -1,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    30,    31,    32,    -1,
       1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,    10,
      11,    -1,    13,    -1,    -1,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    30,
      31,    32,    -1,     1,    -1,    36,     4,     5,     6,    -1,
      -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    30,    31,    32,    -1,     1,    -1,    36,     4,
       5,     6,    -1,    -1,    -1,    10,    11,    -1,    13,    -1,
      -1,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    30,    31,    32,    -1,     1,
      -1,    36,     4,     5,     6,    -1,    -1,    -1,    10,    11,
      -1,    13,    -1,    -1,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    30,    31,
      32,    -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,
      -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    30,    31,    32,    -1,     1,    -1,    36,     4,     5,
       6,    -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,    30,    31,    32,    -1,     1,    -1,
      36,     4,     5,     6,    -1,    -1,    -1,    10,    11,    -1,
      13,    -1,    -1,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    30,    31,    32,
      -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,
      10,    11,    -1,    13,    -1,    -1,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    31,    32,    -1,     1,    -1,    36,     4,     5,     6,
      -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    30,    31,    32,    -1,     1,    -1,    36,
       4,     5,     6,    -1,    -1,    -1,    10,    11,    -1,    13,
      -1,    -1,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    30,    31,    32,    -1,
       1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,    10,
      11,    -1,    13,    -1,    -1,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    30,
      31,    32,    -1,     1,    -1,    36,     4,     5,     6,    -1,
      -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    30,    31,    32,    -1,     1,    -1,    36,     4,
       5,     6,    -1,    -1,    -1,    10,    11,    -1,    13,    -1,
      -1,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    30,    31,    32,    -1,     1,
      -1,    36,     4,     5,     6,    -1,    -1,    -1,    10,    11,
      -1,    13,    -1,    -1,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    30,    31,
      32,    -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,
      -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    30,    31,    32,    -1,     1,    -1,    36,     4,     5,
       6,    -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,    30,    31,    32,    -1,     1,    -1,
      36,     4,     5,     6,    -1,    -1,    -1,    10,    11,    -1,
      13,    -1,    -1,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    30,    31,    32,
      -1,     1,    -1,    36,     4,     5,     6,    -1,    -1,    -1,
      10,    11,    -1,    13,    -1,    -1,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    31,    32,    -1,     1,    -1,    36,     4,     5,     6,
      -1,    -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    30,    31,    32,    -1,     1,    -1,    36,
       4,     5,    -1,    -1,    -1,    -1,    10,    11,    -1,    13,
      -1,    -1,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    30,    31,    32,    -1,
       1,    -1,    36,     4,     5,    -1,    -1,    -1,    -1,    10,
      11,    -1,    13,    -1,    -1,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    30,
      31,    32,    -1,     1,    -1,    36,     4,     5,    -1,    -1,
      -1,    -1,    10,    11,    -1,    13,    -1,    -1,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,     5,    30,    31,    32,    -1,    -1,     7,    36,     5,
      -1,    -1,    -1,    -1,    14,    15,    -1,    21,    -1,    -1,
      -1,     5,    26,    -1,    28,    21,    30,    31,    32,    29,
      26,     7,    36,    -1,    30,    31,    32,    21,    14,    15,
      36,    -1,    26,     7,    -1,    -1,    30,    31,    32,    -1,
      14,    15,    36,    29,     7,    -1,     7,    -1,    34,    35,
      36,    14,    15,    14,    15,    29,     7,    -1,    -1,    -1,
      34,    35,    36,    14,    15,     3,    29,     7,    29,     7,
      -1,    34,    35,    36,    14,    15,    14,    15,    29,     7,
      -1,    -1,    -1,    34,    35,    36,    14,    15,     3,    29,
       7,    29,     7,    -1,    34,    35,    36,    14,    15,    14,
      15,    29,     7,    -1,    -1,    -1,    34,    35,    36,    14,
      15,     3,    29,     7,    29,     7,    -1,    34,    35,    36,
      14,    15,    14,    15,    29,     7,    -1,    -1,    -1,    34,
      35,    36,    14,    15,    -1,    29,     7,    29,     7,    -1,
      34,    35,    36,    14,    15,    14,    15,    29,     7,    -1,
      -1,    -1,    34,    35,    36,    14,    15,    -1,    29,     7,
      29,    -1,    -1,    34,    35,    36,    14,    15,    -1,    -1,
      29,     7,    -1,    -1,    -1,    34,    35,    36,    14,    15,
      -1,    29,    -1,     8,    -1,    -1,    34,    35,    36,    14,
      15,    -1,    -1,    29,    -1,     8,    -1,    -1,    34,    35,
      36,    14,    15,    -1,    29,    -1,     8,    -1,    -1,    34,
      35,    36,    14,    15,    -1,    -1,    29,    -1,     8,    -1,
      -1,    34,    35,    36,    14,    15,    -1,    29,    -1,     8,
      -1,    -1,    34,    35,    36,    14,    15,    -1,    -1,    29,
      -1,     8,    -1,    -1,    34,    35,    36,    14,    15,    -1,
      29,    -1,     8,    -1,    -1,    34,    35,    36,    14,    15,
      -1,    -1,    29,    -1,     8,    -1,    -1,    34,    35,    36,
      14,    15,    -1,    29,    -1,     8,    -1,    -1,    34,    35,
      36,    14,    15,    -1,    -1,    29,    -1,     8,    -1,    -1,
      34,    35,    36,    14,    15,    -1,    29,    -1,     8,    -1,
      -1,    34,    35,    36,    14,    15,    -1,    -1,    29,    -1,
       8,    -1,    -1,    34,    35,    36,    14,    15,    -1,    29,
      -1,     8,    -1,    -1,    34,    35,    36,    14,    15,    -1,
      -1,    29,    -1,     8,    -1,    -1,    34,    35,    36,    14,
      15,    -1,    29,    -1,     8,    -1,    -1,    34,    35,    36,
      14,    15,    -1,    -1,    29,    -1,     8,    -1,    -1,    34,
      35,    36,    14,    15,    -1,    29,    -1,     8,     0,     1,
      34,    35,    36,    14,    15,    -1,    -1,    29,    10,     0,
       1,    13,    34,    35,    36,    14,    15,    -1,    29,    10,
      22,    23,    13,    34,    -1,    36,    14,    15,    -1,    -1,
      29,    22,    23,    -1,    -1,    34,    35,    36,    14,    15,
      -1,    29,    14,    15,    -1,    -1,    34,    35,    36,    -1,
      14,    15,    -1,    29,    14,    15,    -1,    29,    34,    35,
      36,    -1,    34,    35,    36,    29,    14,    15,    -1,    29,
      34,    35,    36,    -1,    34,    35,    36,    14,    15,    -1,
      -1,    29,    -1,    -1,    -1,    -1,    34,    35,    36,    14,
      15,    -1,    29,    14,    15,    -1,    -1,    34,    35,    36,
      -1,    14,    15,    -1,    29,    14,    15,    -1,    29,    34,
      35,    36,    -1,    34,    35,    36,    29,    14,    15,    -1,
      29,    34,    35,    36,     8,    34,    35,    36,    14,    15,
      14,    15,    29,     7,    -1,    -1,    -1,    34,    35,    36,
      14,    15,    -1,    29,     7,    29,     7,    -1,    34,    35,
      36,    14,    15,    14,    15,    29,     7,    -1,    -1,    -1,
      -1,    -1,     7,    14,    15,     7,    29,     7,    29,    14,
      15,    -1,    14,    15,    14,    15,    -1,    -1,    29,    -1,
      -1,    -1,    -1,     7,    29,     7,    -1,    29,     7,    29,
      14,    15,    14,    15,     8,    14,    15,     8,    -1,    -1,
      14,    15,    -1,    14,    15,    29,    -1,    29,    -1,    -1,
      29,    -1,    -1,    -1,    -1,    29,    -1,    -1,    29
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     1,    10,    13,    22,    23,    38,    39,    40,    41,
      46,    76,     0,    39,     5,    32,    39,     7,    43,    44,
      45,    46,     8,     4,    42,     7,     3,    32,     1,     4,
       5,     6,    11,    16,    17,    18,    19,    20,    21,    24,
      25,    26,    27,    28,    30,    31,    32,    36,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    68,    70,
      72,    73,    74,    75,    76,    77,    42,    45,     6,    47,
      57,    65,    75,     5,    71,     5,     8,    57,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     9,    32,    73,
      32,     6,    47,     8,     8,    29,    14,    15,    34,    36,
      35,     8,     8,     6,     7,    57,    47,    48,    57,    58,
      67,     8,    33,    57,    33,    57,    32,    54,    54,    32,
      55,    55,    32,     7,    57,    69,    57,    32,    51,    59,
      59,    60,    61,    62,     7,    12,     8,     7,     7,     7,
       7,     7,     7,     7,     7,    29,     7,     7,     7,     3,
       7,    48,    59,    47,     8,     8,     8,     8,     8,    32,
      51,    47,    57,     8,    58,     5,    21,    26,    28,    30,
      31,    32,    36,    53,    54,    58,    59,    60,    61,    62,
      63,    73,    77,    65,    75,    29,     4,    49,     5,    21,
      26,    28,    30,    31,    32,    36,    53,    57,    58,    59,
      60,    61,    62,    63,    65,    73,    75,    77,     5,    21,
      26,    28,    30,    31,    32,    36,    53,    54,    58,    59,
      60,    61,    62,    63,    65,    73,    75,    77,     8,    24,
      25,    32,    29,     4,    48,    24,    25,    57,     5,     5,
       5,     9,    32,    73,    14,    15,    34,    36,    35,    24,
      25,    32,    51,     6,    47,    47,    57,     5,     5,     5,
       9,    32,    73,    14,    15,    34,    36,    35,    57,     5,
       5,     5,     9,    32,    73,    14,    15,    34,    36,    35,
       5,     5,    24,    25,    32,    51,     6,    47,     5,     5,
       7,    55,    32,     7,    69,    57,    32,    59,    59,    60,
      61,    62,     5,     5,     6,     7,    55,    32,     7,    69,
      54,    57,    57,    59,    59,    60,    61,    62,     7,    55,
      32,     7,    69,    57,    32,    57,    59,    59,    60,    61,
      62,    54,    54,     5,     5,     6,    54,    54,     7,     7,
       7,    54,    54,     7,     7,     7,    29,     7,     7,     7,
       7,     7,    54,    54,     7,     7,     7,     7,    24,    25,
      32,    51,     7,     7,     5,     5,    54,    54,     7,     7
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_int8 yyr1[] =
{
       0,    37,    38,    39,    39,    39,    40,    40,    40,    41,
      42,    42,    43,    44,    44,    45,    46,    46,    46,    46,
      47,    47,    47,    48,    48,    49,    49,    49,    49,    49,
      49,    49,    49,    49,    50,    50,    51,    51,    52,    53,
      54,    54,    55,    55,    56,    57,    58,    58,    59,    59,
      59,    59,    59,    60,    60,    61,    61,    62,    62,    63,
      63,    63,    63,    64,    65,    66,    67,    68,    68,    68,
      68,    68,    69,    69,    70,    70,    71,    72,    72,    73,
      73,    73,    74,    75,    75,    76,    76,    77,    77,    77
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     2,     2,     5,     4,     1,     2,
       3,     2,     1,     3,     1,     2,     1,     1,     1,     1,
       2,     1,     1,     3,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     1,     4,     4,     5,     4,
       3,     3,     3,     3,     2,     1,     1,     3,     1,     1,
       1,     3,     3,     1,     3,     1,     3,     1,     3,     3,
       1,     2,     1,     2,     4,     5,     5,     5,     5,     5,
       5,     5,     3,     1,     3,     5,     3,     3,     2,     1,
       1,     1,     2,     4,     3,     3,     1,     1,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YY_LOCATION_PRINT
#  if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
 }

#   define YY_LOCATION_PRINT(File, Loc)          \
  yy_location_print_ (File, &(Loc))

#  else
#   define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#  endif
# endif /* !defined YY_LOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yykind < YYNTOKENS)
    YYPRINT (yyo, yytoknum[yykind], *yyvaluep);
# endif
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YY_LOCATION_PRINT (yyo, *yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]));
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Location data for the lookahead symbol.  */
YYLTYPE yylloc
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */
  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    goto yyexhaustedlab;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* start: program  */
#line 114 "syntatic.y"
                {
        printf("[SYNTATIC] (start) program\n");
        (yyval.node) = createNode("start");
        (yyval.node)->children = (yyvsp[0].node);

        root = (yyval.node);

    }
#line 2393 "syntatic.tab.c"
    break;

  case 3: /* program: function_definition  */
#line 125 "syntatic.y"
                            {
        printf("[SYNTATIC] (program) function_definition\n");
        (yyval.node) = createNode("program");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2403 "syntatic.tab.c"
    break;

  case 4: /* program: function_definition program  */
#line 130 "syntatic.y"
                                      {
        printf("[SYNTATIC] (program) function_definition program\n");

        (yyval.node) = createNode("program");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyvsp[-1].node)->nxt = (yyvsp[0].node);
    }
#line 2415 "syntatic.tab.c"
    break;

  case 5: /* program: variables_declaration program  */
#line 137 "syntatic.y"
                                        {
        printf("[SYNTATIC] (program) variables_declaration program\n");

        (yyval.node) = createNode("program");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyvsp[-1].node)->nxt = (yyvsp[0].node);
    }
#line 2427 "syntatic.tab.c"
    break;

  case 6: /* function_definition: function_declaration '(' parameters ')' function_body  */
#line 147 "syntatic.y"
                                                              {
        printf("[SYNTATIC] (function_definition) function_declaration '(' parameters ')' function_body\n");
        
        (yyval.node) = createNode("function_definition");
        (yyval.node)->children = (yyvsp[-4].node);
        (yyvsp[-4].node)->nxt = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
    }
#line 2440 "syntatic.tab.c"
    break;

  case 7: /* function_definition: function_declaration '(' ')' function_body  */
#line 155 "syntatic.y"
                                                 {
        printf("[SYNTATIC] (function_definition) function_declaration '(' ')' function_body\n");
        
        (yyval.node) = createNode("function_definition");
        (yyval.node)->children = (yyvsp[-3].node);
        (yyvsp[-3].node)->nxt = (yyvsp[0].node);
    }
#line 2452 "syntatic.tab.c"
    break;

  case 8: /* function_definition: error  */
#line 162 "syntatic.y"
            {}
#line 2458 "syntatic.tab.c"
    break;

  case 9: /* function_declaration: type_identifier ID  */
#line 166 "syntatic.y"
                           {
        push_back(&tableList, createSymbol(lines, columns, "function", lastType, (yyvsp[0].body)));
        printf("[SYNTATIC] (function_declaration) type_identifier ID(%s)\n", (yyvsp[0].body));

        (yyval.node) = createNode("function_declaration");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "variable", lastType, (yyvsp[0].body));
    }
#line 2471 "syntatic.tab.c"
    break;

  case 10: /* function_body: '{' statements '}'  */
#line 177 "syntatic.y"
                           {
        printf("[SYNTATIC] (function_body) '{' statements '}'\n");

        (yyval.node) = createNode("function_body");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 2482 "syntatic.tab.c"
    break;

  case 11: /* function_body: '{' '}'  */
#line 183 "syntatic.y"
              {
        printf("[SYNTATIC] (function_body) '{' '}'\n");

        (yyval.node) = createNode("function_body");
    }
#line 2492 "syntatic.tab.c"
    break;

  case 12: /* parameters: parameters_list  */
#line 191 "syntatic.y"
                        {
        printf("[SYNTATIC] (parameters)  parameters_list \n");

        (yyval.node) = createNode("parameters_list");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2503 "syntatic.tab.c"
    break;

  case 13: /* parameters_list: parameters_list ',' parameter  */
#line 200 "syntatic.y"
                                      {
        printf("[SYNTATIC] (parameters_list) parameter ',' parameters_list\n");

        (yyval.node) = createNode("parameters_list");
        (yyval.node)->children = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
        
    }
#line 2516 "syntatic.tab.c"
    break;

  case 14: /* parameters_list: parameter  */
#line 208 "syntatic.y"
                    {
        printf("[SYNTATIC] (parameters_list) parameter\n");

        (yyval.node) = createNode("parameters_list");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2527 "syntatic.tab.c"
    break;

  case 15: /* parameter: type_identifier ID  */
#line 217 "syntatic.y"
                           {
        printf("[SYNTATIC] (parameter) type_identifier ID(%s)\n", (yyvsp[0].body));

        (yyval.node) = createNode("parameter");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "variable", lastType, (yyvsp[0].body));
    }
#line 2539 "syntatic.tab.c"
    break;

  case 16: /* type_identifier: INT  */
#line 227 "syntatic.y"
            {
        printf("[SYNTATIC] (type_identifier) INT\n");

        (yyval.node) = createNode("type_identifier");
        
        strcpy(lastType, "int");

    }
#line 2552 "syntatic.tab.c"
    break;

  case 17: /* type_identifier: FLOAT  */
#line 235 "syntatic.y"
            {
        printf("[SYNTATIC] (type_identifier) FLOAT\n");

        (yyval.node) = createNode("type_identifier");

        strcpy(lastType, "float");

    }
#line 2565 "syntatic.tab.c"
    break;

  case 18: /* type_identifier: ELEM  */
#line 243 "syntatic.y"
               {
        printf("[SYNTATIC] (type_identifier) ELEM\n");

        (yyval.node) = createNode("type_identifier");

        strcpy(lastType, "elem");

    }
#line 2578 "syntatic.tab.c"
    break;

  case 19: /* type_identifier: SET  */
#line 251 "syntatic.y"
         {
        printf("[SYNTATIC] (type_identifier) SET\n");

        (yyval.node) = createNode("type_identifier");

        strcpy(lastType, "set");

    }
#line 2591 "syntatic.tab.c"
    break;

  case 20: /* statements: statement statements  */
#line 262 "syntatic.y"
                             {
        printf("[SYNTATIC] (statements) statement statements\n");

        (yyval.node) = createNode("statements");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyvsp[-1].node)->nxt = (yyvsp[0].node);
    }
#line 2603 "syntatic.tab.c"
    break;

  case 21: /* statements: statement  */
#line 269 "syntatic.y"
                    {
        printf("[SYNTATIC] (statements) statement\n");   

        (yyval.node) = createNode("statements");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2614 "syntatic.tab.c"
    break;

  case 22: /* statements: statements_braced  */
#line 275 "syntatic.y"
                        {
        printf("[SYNTATIC] (statements) statements_braced\n");

        (yyval.node) = createNode("statements");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2625 "syntatic.tab.c"
    break;

  case 23: /* statements_braced: '{' statements '}'  */
#line 284 "syntatic.y"
                       {
        printf("[SYNTATIC] (statements_braced) '{' statements '}'\n");

        (yyval.node) = createNode("statements_braced");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 2636 "syntatic.tab.c"
    break;

  case 24: /* statements_braced: '{' '}'  */
#line 290 "syntatic.y"
              {
        printf("[SYNTATIC] (statements_braced) '{' '}'\n");

        (yyval.node) = createNode("statements_braced");
    }
#line 2646 "syntatic.tab.c"
    break;

  case 25: /* statement: variables_declaration  */
#line 298 "syntatic.y"
                              {
        printf("[SYNTATIC] (statement) variables_declaration\n");

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2657 "syntatic.tab.c"
    break;

  case 26: /* statement: return  */
#line 304 "syntatic.y"
                 {
        printf("[SYNTATIC] (statement) return\n");

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);    
    }
#line 2668 "syntatic.tab.c"
    break;

  case 27: /* statement: conditional  */
#line 310 "syntatic.y"
                      {
        printf("[SYNTATIC] (statement) conditional\n");   

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);  
    }
#line 2679 "syntatic.tab.c"
    break;

  case 28: /* statement: for  */
#line 316 "syntatic.y"
              {
        printf("[SYNTATIC] (statement) for\n");

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2690 "syntatic.tab.c"
    break;

  case 29: /* statement: is_set_statement  */
#line 322 "syntatic.y"
                       {
        printf("[SYNTATIC] (statement) is_set_statement\n"); 

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);  
    }
#line 2701 "syntatic.tab.c"
    break;

  case 30: /* statement: function_call_statement  */
#line 328 "syntatic.y"
                              {
        printf("[SYNTATIC] (statement) function_call_statement\n"); 

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node); 
    }
#line 2712 "syntatic.tab.c"
    break;

  case 31: /* statement: expression_statement  */
#line 334 "syntatic.y"
                               {
        printf("[SYNTATIC] (statement) expression_statement \n");

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2723 "syntatic.tab.c"
    break;

  case 32: /* statement: io_statement  */
#line 340 "syntatic.y"
                       {
        printf("[SYNTATIC] (statement) io_statement\n");

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);  
    }
#line 2734 "syntatic.tab.c"
    break;

  case 33: /* statement: set_pre_statement  */
#line 346 "syntatic.y"
                            {
        printf("[SYNTATIC] (statement) set_pre_statement\n");

        (yyval.node) = createNode("statement");
        (yyval.node)->children = (yyvsp[0].node);  
    }
#line 2745 "syntatic.tab.c"
    break;

  case 34: /* set_pre_statement: set_statement_add_remove ';'  */
#line 355 "syntatic.y"
                                 {
        printf("[SYNTATIC] (set_pre_statement) set_statement_add_remove ';'\n");  

        (yyval.node) = createNode("set_pre_statement");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 2756 "syntatic.tab.c"
    break;

  case 35: /* set_pre_statement: set_statement_for_all  */
#line 361 "syntatic.y"
                            {
        printf("[SYNTATIC] (set_pre_statement) set_statement_for_all\n");  

        (yyval.node) = createNode("set_pre_statement");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2767 "syntatic.tab.c"
    break;

  case 36: /* set_statement_add_remove: ADD '(' set_boolean_expression ')'  */
#line 370 "syntatic.y"
                                       {
        printf("[SYNTATIC] (set_statement_add_remove) ADD '(' set_boolean_expression ')'\n"); 
        
        (yyval.node) = createNode("set_statement_add_remove");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "set operation", "", "add");
    }
#line 2779 "syntatic.tab.c"
    break;

  case 37: /* set_statement_add_remove: REMOVE '(' set_boolean_expression ')'  */
#line 377 "syntatic.y"
                                            {
        printf("[SYNTATIC] (set_statement_add_remove) REMOVE '(' set_boolean_expression ')'\n"); 

        (yyval.node) = createNode("set_statement_add_remove");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "set operation", "", "remove");
    }
#line 2791 "syntatic.tab.c"
    break;

  case 38: /* set_statement_for_all: FOR_ALL '(' set_assignment_expression ')' statements  */
#line 387 "syntatic.y"
                                                         {
        printf("[SYNTATIC] (set_statement_for_all) FOR_ALL '(' set_assignment_expression ')' statements\n"); 

        (yyval.node) = createNode("set_statement_for_all");
        (yyval.node)->children = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
    }
#line 2803 "syntatic.tab.c"
    break;

  case 39: /* set_statement_exists: EXISTS '(' set_assignment_expression ')'  */
#line 397 "syntatic.y"
                                             {
        printf("[SYNTATIC] (set_statement_exists) EXISTS '(' set_assignment_expression ')'\n"); 

        (yyval.node) = createNode("set_statement_exists");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 2814 "syntatic.tab.c"
    break;

  case 40: /* set_boolean_expression: expression IN set_statement_add_remove  */
#line 406 "syntatic.y"
                                           {
        printf("[SYNTATIC] (set_boolean_expression) expression IN set_statement_add_remove\n");

        (yyval.node) = createNode("set_boolean_expression");
        (yyval.node)->children = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
    }
#line 2826 "syntatic.tab.c"
    break;

  case 41: /* set_boolean_expression: expression IN ID  */
#line 413 "syntatic.y"
                       {
        printf("[SYNTATIC] (set_boolean_expression) expression IN ID(%s)\n", (yyvsp[0].body));

        (yyval.node) = createNode("set_boolean_expression");
        (yyval.node)->children = (yyvsp[-2].node);
    }
#line 2837 "syntatic.tab.c"
    break;

  case 42: /* set_assignment_expression: ID IN set_statement_add_remove  */
#line 422 "syntatic.y"
                                   {
        printf("[SYNTATIC] (set_assignment_expression) expression IN set_statement_add_remove\n");

        (yyval.node) = createNode("set_assignment_expression");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2848 "syntatic.tab.c"
    break;

  case 43: /* set_assignment_expression: ID IN ID  */
#line 428 "syntatic.y"
               {
        printf("[SYNTATIC] (set_assignment_expression) ID(%s) IN ID(%s)\n", (yyvsp[-2].body), (yyvsp[0].body));

        (yyval.node) = createNode("set_assignment_expression");
        (yyval.node)->symbol = createSymbol(lines, columns, "variable", lastType, (yyvsp[-2].body));
    }
#line 2859 "syntatic.tab.c"
    break;

  case 44: /* expression_statement: expression ';'  */
#line 437 "syntatic.y"
                   {
        printf("[SYNTATIC] (expression_statement) expression\n");

        (yyval.node) = createNode("expression_statement");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 2870 "syntatic.tab.c"
    break;

  case 45: /* expression: expression_assignment  */
#line 446 "syntatic.y"
                          {
        printf("[SYNTATIC] (expression) expression_assignment\n");

        (yyval.node) = createNode("expression");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 2881 "syntatic.tab.c"
    break;

  case 46: /* expression_assignment: expression_logical  */
#line 455 "syntatic.y"
                       {
        printf("[SYNTATIC] (expression_assignment) expression_logical\n");

        (yyval.node) = createNode("expression_assignment");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2892 "syntatic.tab.c"
    break;

  case 47: /* expression_assignment: ID '=' expression  */
#line 461 "syntatic.y"
                        {
        printf("[SYNTATIC] (expression_assignment) ID(%s) '='  expression\n", (yyvsp[-2].body));

        (yyval.node) = createNode("expression_assignment");
        (yyval.node)->children = (yyvsp[0].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "variable", lastType, (yyvsp[-2].body));
    }
#line 2904 "syntatic.tab.c"
    break;

  case 48: /* expression_logical: expression_relational  */
#line 471 "syntatic.y"
                          {
        printf("[SYNTATIC] (expression_logical) expression_relational\n");

        (yyval.node) = createNode("expression_logical");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2915 "syntatic.tab.c"
    break;

  case 49: /* expression_logical: set_boolean_expression  */
#line 477 "syntatic.y"
                             {
        printf("[SYNTATIC] (expression_logical) set_expression\n");

        (yyval.node) = createNode("expression_logical");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2926 "syntatic.tab.c"
    break;

  case 50: /* expression_logical: is_set_expression  */
#line 483 "syntatic.y"
                        {
        printf("[SYNTATIC] (is_set_expression) is_set_expression\n");

        (yyval.node) = createNode("expression_logical");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2937 "syntatic.tab.c"
    break;

  case 51: /* expression_logical: expression_logical AND_OP expression_logical  */
#line 489 "syntatic.y"
                                                   {
        printf("[SYNTATIC] (expression_logical) expression_logical AND_OP(&&) expression_logical\n");

        (yyval.node) = createNode("expression_logical");
        (yyval.node)->children = (yyvsp[-2].node);   
    }
#line 2948 "syntatic.tab.c"
    break;

  case 52: /* expression_logical: expression_logical OR_OP expression_logical  */
#line 495 "syntatic.y"
                                                  {
        printf("[SYNTATIC] (expression_logical) expression_logical OR_OP(||) expression_logical\n");

        (yyval.node) = createNode("expression_logical");
        (yyval.node)->children = (yyvsp[-2].node);   
    }
#line 2959 "syntatic.tab.c"
    break;

  case 53: /* expression_relational: expression_additive  */
#line 504 "syntatic.y"
                        {
        printf("[SYNTATIC] (expression_relational) expression_additive \n");

        (yyval.node) = createNode("expression_relational");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2970 "syntatic.tab.c"
    break;

  case 54: /* expression_relational: expression_relational RELATIONAL_OP expression_relational  */
#line 510 "syntatic.y"
                                                                {
        printf("[SYNTATIC] (expression_relational) expression_relational RELATIONAL_OP(%s) expression_relational\n", (yyvsp[-1].body));

        (yyval.node) = createNode("expression_relational");
        (yyval.node)->children = (yyvsp[-2].node);   
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "relational operator", "", (yyvsp[-1].body));
    }
#line 2983 "syntatic.tab.c"
    break;

  case 55: /* expression_additive: expression_multiplicative  */
#line 521 "syntatic.y"
                              {
        printf("[SYNTATIC] (expression_additive) expression_multiplicative \n");
    
        (yyval.node) = createNode("expression_additive");
        (yyval.node)->children = (yyvsp[0].node);   
    }
#line 2994 "syntatic.tab.c"
    break;

  case 56: /* expression_additive: expression_additive ADDITIVE_OP expression_additive  */
#line 527 "syntatic.y"
                                                          {
        printf("[SYNTATIC] (expression_additive) expression_additive ADDITIVE_OP(%s) expression_additive \n", (yyvsp[-1].body));

        (yyval.node) = createNode("expression_additive");
        (yyval.node)->children = (yyvsp[-2].node);   
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "additive operator", "", (yyvsp[-1].body));
    }
#line 3007 "syntatic.tab.c"
    break;

  case 57: /* expression_multiplicative: expression_value  */
#line 538 "syntatic.y"
                     {
        printf("[SYNTATIC] (expression_multiplicative) expression_value \n");

        (yyval.node) = createNode("expression_multiplicative");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 3018 "syntatic.tab.c"
    break;

  case 58: /* expression_multiplicative: expression_multiplicative MULTIPLICATIVE_OP expression_multiplicative  */
#line 544 "syntatic.y"
                                                                            {
        printf("[SYNTATIC] (expression_multiplicative)  expression_multiplicative MULTIPLICATIVE_OP(%s) expression_multiplicative \n", (yyvsp[-1].body));

        (yyval.node) = createNode("expression_multiplicative");
        (yyval.node)->children = (yyvsp[-2].node);   
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
        (yyval.node)->symbol = createSymbol(lines, columns, "multiplicative operator", "", (yyvsp[-1].body));
    }
#line 3031 "syntatic.tab.c"
    break;

  case 59: /* expression_value: '(' expression ')'  */
#line 555 "syntatic.y"
                       {
        printf("[SYNTATIC] (expression_value) '(' expression ')' \n");

        (yyval.node) = createNode("expression_value");
        (yyval.node)->children = (yyvsp[-1].node);   
    }
#line 3042 "syntatic.tab.c"
    break;

  case 60: /* expression_value: value  */
#line 561 "syntatic.y"
            {
        printf("[SYNTATIC] (expression_value) value \n");

        (yyval.node) = createNode("expression_value");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 3053 "syntatic.tab.c"
    break;

  case 61: /* expression_value: ADDITIVE_OP value  */
#line 567 "syntatic.y"
                        {
        printf("[SYNTATIC] (expression_value) ADDITIVE_OP(%s) value \n", (yyvsp[-1].body));

        (yyval.node) = createNode("expression_value");
        (yyval.node)->children = (yyvsp[0].node);  
        (yyval.node)->symbol = createSymbol(lines, columns, "additive operator", "", (yyvsp[-1].body));
    }
#line 3065 "syntatic.tab.c"
    break;

  case 62: /* expression_value: set_statement_exists  */
#line 574 "syntatic.y"
                           {
        printf("[SYNTATIC] (expression_value) set_statement_exists\n");

        (yyval.node) = createNode("expression_value");
        (yyval.node)->children = (yyvsp[0].node);  
    }
#line 3076 "syntatic.tab.c"
    break;

  case 63: /* is_set_statement: is_set_expression ';'  */
#line 583 "syntatic.y"
                          {
        printf("[SYNTATIC] (is_set_statement) is_set_expression ';'\n");

        (yyval.node) = createNode("is_set_statement");
        (yyval.node)->children = (yyvsp[-1].node);  
    }
#line 3087 "syntatic.tab.c"
    break;

  case 64: /* is_set_expression: IS_SET '(' ID ')'  */
#line 592 "syntatic.y"
                      {
        printf("[SYNTATIC] (is_set) IS_SET '(' ID(%s) ')' ';'\n", (yyvsp[-1].body));

        (yyval.node) = createNode("is_set_expression");
        (yyval.node)->symbol = createSymbol(lines, columns, "variable", lastType, (yyvsp[-1].body)); 
    }
#line 3098 "syntatic.tab.c"
    break;

  case 65: /* for: FOR '(' for_expression ')' statements  */
#line 601 "syntatic.y"
                                          {
        printf("[SYNTATIC] (for) FOR '(' for_expression ')' statement\n");

        (yyval.node) = createNode("for");
        (yyval.node)->children = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);  
    }
#line 3110 "syntatic.tab.c"
    break;

  case 66: /* for_expression: expression_assignment ';' expression_logical ';' expression_assignment  */
#line 611 "syntatic.y"
                                                                           {
        printf("[SYNTATIC] (for_expression) expression_assignment ';' expression_logical ';' expression_assignment\n");
        
        (yyval.node) = createNode("for_expression");
        (yyval.node)->children = (yyvsp[-4].node);
        (yyvsp[-4].node)->nxt = (yyvsp[-2].node);  
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);  
    }
#line 3123 "syntatic.tab.c"
    break;

  case 67: /* io_statement: READ '(' ID ')' ';'  */
#line 622 "syntatic.y"
                        {
        printf("[SYNTATIC] (io_statement) READ '(' ID(%s) ')' ';'\n", (yyvsp[-2].body));

        (yyval.node) = createNode("io_statement");
    }
#line 3133 "syntatic.tab.c"
    break;

  case 68: /* io_statement: WRITE '(' STRING ')' ';'  */
#line 627 "syntatic.y"
                               {
        printf("[SYNTATIC] (io_statement) WRITE '(' STRING(%s) ')' ';'\n", (yyvsp[-2].body));

        (yyval.node) = createNode("io_statement");
        (yyval.node)->symbol = createSymbol(lines, columns, "string", "", (yyvsp[-2].body));
    }
#line 3144 "syntatic.tab.c"
    break;

  case 69: /* io_statement: WRITE '(' expression ')' ';'  */
#line 633 "syntatic.y"
                                   {
        printf("[SYNTATIC] (io_statement) WRITE '(' expression ')' ';'\n");

        (yyval.node) = createNode("io_statement");
        (yyval.node)->children = (yyvsp[-2].node);
    }
#line 3155 "syntatic.tab.c"
    break;

  case 70: /* io_statement: WRITELN '(' STRING ')' ';'  */
#line 639 "syntatic.y"
                                 {
        printf("[SYNTATIC] (io_statement) WRITELN '(' STRING(%s) ')' ';'\n", (yyvsp[-2].body));

        (yyval.node) = createNode("io_statement");
        (yyval.node)->symbol = createSymbol(lines, columns, "string", "", (yyvsp[-2].body));
    }
#line 3166 "syntatic.tab.c"
    break;

  case 71: /* io_statement: WRITELN '(' expression ')' ';'  */
#line 645 "syntatic.y"
                                     {
        printf("[SYNTATIC] (io_statement) WRITELN '(' expression ')' ';'\n");

        (yyval.node) = createNode("io_statement");
        (yyval.node)->children = (yyvsp[-2].node);
    }
#line 3177 "syntatic.tab.c"
    break;

  case 72: /* arguments_list: arguments_list ',' expression  */
#line 654 "syntatic.y"
                                  {
        printf("[SYNTATIC] (arguments_list) arguments_list ',' expression\n");

        (yyval.node) = createNode("arguments_list");
        (yyval.node)->children = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
    }
#line 3189 "syntatic.tab.c"
    break;

  case 73: /* arguments_list: expression  */
#line 661 "syntatic.y"
                 {
        printf("[SYNTATIC] (arguments_list) expression\n");

        (yyval.node) = createNode("arguments_list");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 3200 "syntatic.tab.c"
    break;

  case 74: /* conditional: IF conditional_expression statements  */
#line 670 "syntatic.y"
                                         {
        printf("[SYNTATIC] (conditional) IF conditional_expression statements\n");

        (yyval.node) = createNode("conditional");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyvsp[-1].node)->nxt = (yyvsp[0].node);
    }
#line 3212 "syntatic.tab.c"
    break;

  case 75: /* conditional: IF conditional_expression statements_braced ELSE statements_braced  */
#line 677 "syntatic.y"
                                                                         {
        printf("[SYNTATIC] (conditional) IF conditional_expression statements_braced ELSE statements_braced\n");

        (yyval.node) = createNode("conditional");
        (yyval.node)->children = (yyvsp[-3].node);
        (yyvsp[-3].node)->nxt = (yyvsp[-2].node);
        (yyvsp[-2].node)->nxt = (yyvsp[0].node);
    }
#line 3225 "syntatic.tab.c"
    break;

  case 76: /* conditional_expression: '(' expression ')'  */
#line 688 "syntatic.y"
                       {
        printf("[SYNTATIC] (conditional_expression) '(' expression ')'\n");

        (yyval.node) = createNode("conditional_expression");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 3236 "syntatic.tab.c"
    break;

  case 77: /* return: RETURN expression ';'  */
#line 697 "syntatic.y"
                          {
        printf("[SYNTATIC] (return) RETURN expression ';'\n");

        (yyval.node) = createNode("return");
        (yyval.node)->children = (yyvsp[-1].node);
    }
#line 3247 "syntatic.tab.c"
    break;

  case 78: /* return: RETURN ';'  */
#line 703 "syntatic.y"
                 {
        printf("[SYNTATIC] (return) RETURN ';'\n");

        (yyval.node) = createNode("return");
    }
#line 3257 "syntatic.tab.c"
    break;

  case 79: /* value: ID  */
#line 711 "syntatic.y"
       {
        printf("[SYNTATIC] (value) ID = %s\n", (yyvsp[0].body));

        (yyval.node) = createNode("value");
        (yyval.node)->symbol = createSymbol(lines, columns, "variable", lastType, (yyvsp[0].body));
    }
#line 3268 "syntatic.tab.c"
    break;

  case 80: /* value: const  */
#line 717 "syntatic.y"
            {
        printf("[SYNTATIC] (value) const\n");

        (yyval.node) = createNode("value");
        (yyval.node)->children = (yyvsp[0].node);

    }
#line 3280 "syntatic.tab.c"
    break;

  case 81: /* value: function_call  */
#line 724 "syntatic.y"
                    {
        printf("[SYNTATIC] (value) function_call\n");

        (yyval.node) = createNode("value");
        (yyval.node)->children = (yyvsp[0].node);
    }
#line 3291 "syntatic.tab.c"
    break;

  case 82: /* function_call_statement: function_call ';'  */
#line 733 "syntatic.y"
                      {
        printf("[SYNTATIC] (function_call_statement) function_call ';'\n");
        
        (yyval.node) = createNode("function_call_statement");
        (yyval.node)->children = (yyvsp[-1].node);

    }
#line 3303 "syntatic.tab.c"
    break;

  case 83: /* function_call: ID '(' arguments_list ')'  */
#line 743 "syntatic.y"
                              {
        printf("[SYNTATIC] (function_call) ID(%s) '(' arguments_list ')'\n", (yyvsp[-3].body));

        Symbol* s = createSymbol(lines, columns, "function_call", "", (yyvsp[-3].body));
        (yyval.node) = createNode("function_call");
        (yyval.node)->children = (yyvsp[-1].node);
        (yyval.node)->symbol = s;
    }
#line 3316 "syntatic.tab.c"
    break;

  case 84: /* function_call: ID '(' ')'  */
#line 751 "syntatic.y"
                 {
        printf("[SYNTATIC] (function_call) ID(%s) '(' ')'\n", (yyvsp[-2].body));

        Symbol* s = createSymbol(lines, columns, "function_call", "", (yyvsp[-2].body));
        (yyval.node) = createNode("function_call");
        (yyval.node)->symbol = s;
    }
#line 3328 "syntatic.tab.c"
    break;

  case 85: /* variables_declaration: type_identifier ID ';'  */
#line 761 "syntatic.y"
                           {
        printf("[SYNTATIC] (variables_declaration) type_identifier ID(%s) ';'\n", (yyvsp[-1].body));
        
        push_back(&tableList, createSymbol(lines, columns, "variable", lastType, (yyvsp[-1].body)));
        
        Symbol* s = createSymbol(lines, columns, "variable", lastType, (yyvsp[-1].body));
        (yyval.node) = createNode("variables_declaration");
        (yyval.node)->children = (yyvsp[-2].node);
        (yyval.node)->symbol = s;
    }
#line 3343 "syntatic.tab.c"
    break;

  case 86: /* variables_declaration: error  */
#line 771 "syntatic.y"
            {}
#line 3349 "syntatic.tab.c"
    break;

  case 87: /* const: INT_VALUE  */
#line 775 "syntatic.y"
              {
        printf("[SYNTATIC] (const) INT_VALUE = %s\n", (yyvsp[0].body));
        
        (yyval.node) = createNode("const");
        (yyval.node)->symbol = createSymbol(lines, columns, "const", "int", (yyvsp[0].body));

    }
#line 3361 "syntatic.tab.c"
    break;

  case 88: /* const: FLOAT_VALUE  */
#line 782 "syntatic.y"
                  {
        printf("[SYNTATIC] (const) FLOAT_VALUE = %s\n", (yyvsp[0].body));
        
        (yyval.node) = createNode("const");
        (yyval.node)->symbol = createSymbol(lines, columns, "const", "float", (yyvsp[0].body));
    }
#line 3372 "syntatic.tab.c"
    break;

  case 89: /* const: EMPTY  */
#line 788 "syntatic.y"
            {
        printf("[SYNTATIC] (const) EMPTY\n");
        
        (yyval.node) = createNode("const");
        (yyval.node)->symbol = createSymbol(lines, columns, "const", "empty", "EMPTY");
    }
#line 3383 "syntatic.tab.c"
    break;


#line 3387 "syntatic.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          goto yyexhaustedlab;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;


#if 1
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturn;
#endif


/*-------------------------------------------------------.
| yyreturn -- parsing is finished, clean up and return.  |
`-------------------------------------------------------*/
yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 796 "syntatic.y"


int yyerror(const char* message){
    printf("[SYNTATIC] ERROR [%d:%d] %s\n", lines, columns, message);
    errors++;
    return 0;
}

int main(int argc, char ** argv) {
    ++argv, --argc;
    if(argc > 0) {
        yyin = fopen(argv[0], "r");
    }
    else {
        yyin = stdin;
    }

    stackScope.size = stackScope.nxtScope = -1;
    tableList.size = -1;

    push(&stackScope);

    lines = 0;
    columns = 0;
    errors = 0;

    int ok[10000];
    memset(ok, 0, sizeof(ok));

    yyparse();
    printf("\n");

    if(errors){
        printf("Program analysis failed!\nAnalysis terminated with %d error(s)\n\n", errors);
    }
    else{
        printf("Correct program.\n\n");
    }

    if(errors){
        printf("Symbol table and Tree won't be displayed because unexpected behaviour can be found since it contains erros\n");
    } else {
        printTable(&tableList);
        printf("\n");
        printTree(root, 1, ok);
    }    

    freeTree(root);
    freeTable(&tableList);
    fclose(yyin);
    yylex_destroy();

    return 0;
}
